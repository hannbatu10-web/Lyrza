//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-AT_sF-au.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D0x5y4YA.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D0x5y4YA.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dmq8TLeN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
