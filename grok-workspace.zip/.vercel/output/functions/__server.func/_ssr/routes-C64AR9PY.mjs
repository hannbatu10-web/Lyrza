import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, c as Eraser, d as ChevronLeft, f as ChevronDown, i as RotateCcw, l as ChevronUp, n as Volume2, o as Pause, p as Bird, s as House, t as VolumeX, u as ChevronRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C64AR9PY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var def = (id, name, category, color, flags = {}) => ({
	id,
	name,
	category,
	color,
	solid: flags.solid ?? true,
	background: flags.background ?? false,
	climb: flags.climb ?? false,
	liquid: flags.liquid ?? false,
	transparent: flags.transparent ?? false,
	unbreakable: flags.unbreakable ?? false,
	hotbar: flags.hotbar ?? true
});
var ID = {
	air: 0,
	grass: 1,
	dirt: 2,
	stone: 3,
	cobble: 4,
	log: 5,
	planks: 6,
	leaves: 7,
	sand: 8,
	brick: 9,
	glass: 10,
	stonebrick: 11,
	woolRed: 12,
	woolBlue: 13,
	woolYellow: 14,
	woolWhite: 15,
	woolGreen: 16,
	door: 17,
	torch: 18,
	flower: 19,
	bed: 20,
	chest: 21,
	table: 22,
	ladder: 23,
	bookshelf: 24,
	furnace: 25,
	bgWood: 26,
	bgStone: 27,
	wallpaper: 28,
	bedrock: 29,
	hay: 30,
	woolPink: 31,
	water: 32
};
var BLOCKS = [];
BLOCKS[ID.grass] = def(ID.grass, "Çimen", "doga", "#5ea842");
BLOCKS[ID.dirt] = def(ID.dirt, "Toprak", "doga", "#8d5a34");
BLOCKS[ID.stone] = def(ID.stone, "Taş", "doga", "#8a8a8e");
BLOCKS[ID.cobble] = def(ID.cobble, "Kırıktaş", "doga", "#6e6e72");
BLOCKS[ID.log] = def(ID.log, "Odun", "doga", "#6b4428");
BLOCKS[ID.planks] = def(ID.planks, "Tahta", "yapi", "#c49a5c");
BLOCKS[ID.leaves] = def(ID.leaves, "Yaprak", "doga", "#3e8c34", { transparent: true });
BLOCKS[ID.sand] = def(ID.sand, "Kum", "doga", "#e4d2a0");
BLOCKS[ID.brick] = def(ID.brick, "Tuğla", "yapi", "#b4543e");
BLOCKS[ID.glass] = def(ID.glass, "Cam", "yapi", "#c5e4f2", { transparent: true });
BLOCKS[ID.stonebrick] = def(ID.stonebrick, "Taş tuğla", "yapi", "#9a9aa0");
BLOCKS[ID.woolRed] = def(ID.woolRed, "Kırmızı yün", "yapi", "#c44850");
BLOCKS[ID.woolBlue] = def(ID.woolBlue, "Mavi yün", "yapi", "#3d78c4");
BLOCKS[ID.woolYellow] = def(ID.woolYellow, "Sarı yün", "yapi", "#e0b84a");
BLOCKS[ID.woolWhite] = def(ID.woolWhite, "Beyaz yün", "yapi", "#f2f0ea");
BLOCKS[ID.woolGreen] = def(ID.woolGreen, "Yeşil yün", "yapi", "#3c9a58");
BLOCKS[ID.door] = def(ID.door, "Kapı", "yapi", "#a87440", {
	solid: false,
	transparent: true
});
BLOCKS[ID.torch] = def(ID.torch, "Meşale", "dekor", "#f0a030", {
	solid: false,
	transparent: true
});
BLOCKS[ID.flower] = def(ID.flower, "Çiçek", "dekor", "#ef7090", {
	solid: false,
	transparent: true
});
BLOCKS[ID.bed] = def(ID.bed, "Yatak", "dekor", "#c43c48", {
	solid: false,
	transparent: true
});
BLOCKS[ID.chest] = def(ID.chest, "Sandık", "dekor", "#a86a32");
BLOCKS[ID.table] = def(ID.table, "Masa", "dekor", "#c48a48", {
	solid: false,
	transparent: true
});
BLOCKS[ID.ladder] = def(ID.ladder, "Merdiven", "yapi", "#a87844", {
	solid: false,
	climb: true,
	transparent: true
});
BLOCKS[ID.bookshelf] = def(ID.bookshelf, "Kitaplık", "dekor", "#8a5a32");
BLOCKS[ID.furnace] = def(ID.furnace, "Ocak", "dekor", "#6a6a6e");
BLOCKS[ID.bgWood] = def(ID.bgWood, "Arka tahta", "oda", "#6e5434", {
	solid: false,
	background: true
});
BLOCKS[ID.bgStone] = def(ID.bgStone, "Arka taş", "oda", "#5c5c64", {
	solid: false,
	background: true
});
BLOCKS[ID.wallpaper] = def(ID.wallpaper, "Duvar kağıdı", "oda", "#f0e2c4", {
	solid: false,
	background: true
});
BLOCKS[ID.bedrock] = def(ID.bedrock, "Ana kaya", "doga", "#1c1c20", {
	hotbar: false,
	unbreakable: true
});
BLOCKS[ID.hay] = def(ID.hay, "Saman", "doga", "#e0b848");
BLOCKS[ID.woolPink] = def(ID.woolPink, "Pembe yün", "yapi", "#e088b0");
BLOCKS[ID.water] = def(ID.water, "Su", "doga", "#3a8ec8", {
	solid: false,
	liquid: true,
	transparent: true
});
var CATEGORIES = [
	{
		id: "doga",
		label: "Doğa"
	},
	{
		id: "yapi",
		label: "Yapı"
	},
	{
		id: "dekor",
		label: "Eşya"
	},
	{
		id: "oda",
		label: "Oda"
	}
];
function hotbar(category) {
	const list = [];
	for (const block of BLOCKS) if (block && block.hotbar && block.category === category) list.push(block);
	return list;
}
function blockAt(id) {
	return BLOCKS[id] ?? null;
}
function atlasCell(id) {
	if (id <= 0) return null;
	const a = id - 1;
	return {
		col: a % 8,
		row: Math.floor(a / 8)
	};
}
var Sfx = class {
	ctx = null;
	muted = false;
	unlock() {
		if (!this.ctx) {
			const AC = window.AudioContext || window.webkitAudioContext;
			if (!AC) return;
			this.ctx = new AC();
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	tone(freq, dur, type, gain = .04) {
		if (this.muted || !this.ctx) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq, t);
		g.gain.setValueAtTime(gain, t);
		g.gain.exponentialRampToValueAtTime(.001, t + dur);
		osc.connect(g);
		g.connect(this.ctx.destination);
		osc.start(t);
		osc.stop(t + dur);
	}
	noise(dur = .07, freq = 700) {
		if (this.muted || !this.ctx) return;
		const rate = this.ctx.sampleRate;
		const length = Math.floor(rate * dur);
		const buffer = this.ctx.createBuffer(1, length, rate);
		const data = buffer.getChannelData(0);
		for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
		const src = this.ctx.createBufferSource();
		src.buffer = buffer;
		const filter = this.ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = freq;
		const g = this.ctx.createGain();
		g.gain.value = .08;
		src.connect(filter);
		filter.connect(g);
		g.connect(this.ctx.destination);
		src.start();
	}
	place() {
		this.tone(210, .05, "square", .03);
		this.tone(140, .07, "triangle", .03);
	}
	break() {
		this.noise(.08, 500);
	}
	jump() {
		this.tone(480, .07, "square", .03);
		this.tone(720, .09, "square", .025);
	}
	fly(on) {
		this.tone(on ? 520 : 280, .12, "sine", .04);
	}
};
var TILE = 16;
var SAVE_KEY = "blokyuva-save-v1";
var CELL_W = 28;
var CELL_H = 36;
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function approach(v, target, max) {
	if (v < target) return Math.min(target, v + max);
	return Math.max(target, v - max);
}
function b64(bytes) {
	let s = "";
	for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i] ?? 0);
	return btoa(s);
}
function unb64(text) {
	const bin = atob(text);
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
	return out;
}
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.onload = () => resolve(img);
		img.onerror = () => reject(new Error(src));
		img.src = src;
	});
}
var Engine = class {
	canvas;
	ui;
	ctx;
	off;
	octx;
	sfx = new Sfx();
	keys = /* @__PURE__ */ new Set();
	prevKeys = /* @__PURE__ */ new Set();
	forced = null;
	touch = {
		left: false,
		right: false,
		up: false,
		down: false,
		jump: false
	};
	prevJump = false;
	raf = 0;
	last = 0;
	acc = 0;
	frame = 0;
	iw = 320;
	ih = 180;
	camX = 0;
	camY = 0;
	anim = 0;
	coyote = 0;
	jumpBuffer = 0;
	holdPlace = 0;
	holdBreak = 0;
	shake = 0;
	clock = 0;
	saveTimer = 0;
	painting = null;
	lastPaint = "";
	aim = null;
	flying = false;
	fg = /* @__PURE__ */ new Uint8Array(28e3);
	bg = /* @__PURE__ */ new Uint8Array(28e3);
	light = /* @__PURE__ */ new Uint8Array(28e3);
	seed = 1;
	particles = [];
	atlas = null;
	walk = null;
	jumpSheet = null;
	clouds = [];
	player = {
		x: 8,
		y: 8,
		w: .62,
		h: 1.72,
		vx: 0,
		vy: 0,
		facing: 1,
		grounded: false
	};
	onHud = null;
	onSlot = null;
	onPauseToggle = null;
	onPick = null;
	constructor(canvas, ui) {
		this.canvas = canvas;
		this.ui = ui;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("canvas");
		this.ctx = ctx;
		this.off = document.createElement("canvas");
		const octx = this.off.getContext("2d");
		if (!octx) throw new Error("offscreen");
		this.octx = octx;
		if (!this.load()) this.generate(false);
		this.resize();
		this.snapCamera(true);
		this.bind();
		this.attachProbe();
		this.loadArt();
		for (let i = 0; i < 7; i++) this.clouds.push({
			x: i * 47 % 280,
			y: 4 + i % 3 * 3,
			w: 6 + i % 4,
			s: .4 + i % 3 * .15
		});
	}
	start() {
		this.last = performance.now();
		const loop = (t) => {
			const dt = Math.min(.05, (t - this.last) / 1e3 || 0);
			this.last = t;
			this.clock += dt;
			if (this.ui.current.started && !this.ui.current.paused) {
				this.acc += dt;
				let guard = 0;
				while (this.acc >= 1 / 60 && guard++ < 5) {
					this.step(1 / 60);
					this.acc -= 1 / 60;
				}
			} else {
				this.acc = 0;
				this.sampleEdges();
			}
			this.render();
			this.raf = requestAnimationFrame(loop);
		};
		this.raf = requestAnimationFrame(loop);
	}
	destroy() {
		cancelAnimationFrame(this.raf);
		this.unbind();
		if (window.__controlsTest?.setKeys === this.probeSetKeys) delete window.__controlsTest;
		delete window.__blokyuva;
	}
	setTouch(key, down) {
		this.touch[key] = down;
		if (down) this.sfx.unlock();
	}
	toggleFly() {
		this.flying = !this.flying;
		if (this.flying) this.player.vy = 0;
		this.sfx.unlock();
		this.sfx.fly(this.flying);
		this.emitHud(true);
		this.queueSave();
	}
	unlock() {
		this.sfx.unlock();
	}
	stamp(kind) {
		const floor = Math.floor(this.player.y + this.player.h + .001);
		const px = Math.floor(this.player.x);
		const width = kind === "cottage" ? 10 : 8;
		let x0 = px + (this.player.facing > 0 ? 2 : -(width + 1));
		x0 = Math.max(2, Math.min(280 - width - 2, x0));
		if (kind === "cottage") this.buildCottage(x0, floor);
		else this.buildRoom(x0, floor);
		this.queueSave();
	}
	resetWorld() {
		try {
			localStorage.removeItem(SAVE_KEY);
		} catch {}
		this.generate(true);
		this.flying = false;
		this.particles = [];
		this.snapCamera(true);
		this.emitHud(true);
	}
	idx(x, y) {
		return y * 280 + x;
	}
	inBounds(x, y) {
		return x >= 0 && y >= 0 && x < 280 && y < 100;
	}
	getFg(x, y) {
		if (!this.inBounds(x, y)) return ID.bedrock;
		return this.fg[this.idx(x, y)] ?? 0;
	}
	getBg(x, y) {
		if (!this.inBounds(x, y)) return 0;
		return this.bg[this.idx(x, y)] ?? 0;
	}
	solid(id) {
		return blockAt(id)?.solid ?? false;
	}
	setFg(x, y, id) {
		if (!this.inBounds(x, y)) return false;
		if (this.fg[this.idx(x, y)] === ID.bedrock) return false;
		this.fg[this.idx(x, y)] = id;
		this.recomputeColumn(x);
		return true;
	}
	setBg(x, y, id) {
		if (!this.inBounds(x, y)) return false;
		this.bg[this.idx(x, y)] = id;
		return true;
	}
	recomputeColumn(x) {
		let sun = 255;
		for (let y = 0; y < 100; y++) {
			const i = this.idx(x, y);
			this.light[i] = sun;
			const block = blockAt(this.fg[i] ?? 0);
			if (!block) continue;
			if (block.liquid) sun = Math.max(110, sun - 30);
			else if (block.transparent && block.solid) sun = Math.max(150, sun - 28);
			else if (block.solid) sun = Math.max(58, sun - 78);
		}
	}
	recomputeAll() {
		for (let x = 0; x < 280; x++) this.recomputeColumn(x);
	}
	generate(forceNew) {
		this.seed = forceNew ? Math.random() * 1e9 | 0 : 1369948382;
		const rand = mulberry32(this.seed);
		this.fg.fill(0);
		this.bg.fill(0);
		const surface = (x) => {
			const n = Math.sin(x * .045 + this.seed * 1e-5) * 5 + Math.sin(x * .013 + this.seed * 2e-6) * 8 + Math.sin(x * .1 + 2) * 1.5;
			return Math.max(22, Math.min(72, Math.floor(38 + n)));
		};
		const waterLine = 46;
		for (let x = 0; x < 280; x++) {
			const s0 = surface(x);
			const lake = s0 > waterLine;
			const top = lake ? waterLine : s0;
			for (let y = 0; y < 100; y++) {
				if (y >= 98) {
					this.fg[this.idx(x, y)] = ID.bedrock;
					continue;
				}
				if (lake && y >= waterLine && y < s0) {
					this.fg[this.idx(x, y)] = ID.water;
					continue;
				}
				if (y < top) continue;
				const depth = y - (lake ? s0 : top);
				let id = ID.stone;
				if (!lake && depth === 0) id = ID.grass;
				else if (lake && y < s0 + 4) id = ID.sand;
				else if (!lake && depth < 4 + x % 3) id = ID.dirt;
				else id = ID.stone;
				const cave = y > top + 6 && Math.sin(x * .21 + this.seed) + Math.sin(y * .27) + Math.sin((x + y) * .11) > 1.72;
				this.fg[this.idx(x, y)] = cave ? 0 : id;
			}
		}
		for (let x = 4; x < 276; x++) {
			const s = surface(x);
			if (s >= 45) continue;
			if (!(Math.abs(surface(x - 1) - s) < 2 && Math.abs(surface(x + 1) - s) < 2)) continue;
			if (rand() < .09) {
				const h = 4 + rand() * 3 | 0;
				const base = s - 1;
				for (let i = 0; i < h; i++) this.fg[this.idx(x, base - i)] = ID.log;
				const crown = base - h + 1;
				for (let dy = -2; dy <= 1; dy++) for (let dx = -2; dx <= 2; dx++) {
					if (Math.abs(dx) + Math.abs(dy) > 3) continue;
					const tx = x + dx;
					const ty = crown + dy;
					if (this.inBounds(tx, ty) && this.fg[this.idx(tx, ty)] === 0) this.fg[this.idx(tx, ty)] = ID.leaves;
				}
			} else if (rand() < .05) this.fg[this.idx(x, s - 1)] = ID.flower;
			else if (rand() < .02) this.fg[this.idx(x, s - 1)] = ID.cobble;
		}
		let spawnX = 70;
		for (let x = 40; x < 140; x++) if (surface(x) < 44 && Math.abs(surface(x) - surface(x + 12)) <= 1) {
			spawnX = x;
			break;
		}
		const floor = surface(spawnX);
		for (let x = spawnX - 8; x <= spawnX + 18; x++) {
			if (!this.inBounds(x, floor)) continue;
			for (let y = 0; y < floor; y++) this.fg[this.idx(x, y)] = 0;
			if (this.fg[this.idx(x, floor)] !== ID.bedrock) this.fg[this.idx(x, floor)] = ID.grass;
		}
		this.buildCottage(spawnX + 5, floor);
		this.player.x = spawnX + .4;
		this.player.y = floor - this.player.h;
		this.player.vx = 0;
		this.player.vy = 0;
		this.player.facing = 1;
		this.player.grounded = true;
		this.recomputeAll();
		this.unstuck();
	}
	carveRoom(x0, x1, floor, roof, wall, doorX) {
		for (let x = x0; x <= x1; x++) {
			this.setFg(x, floor, ID.planks);
			this.setFg(x, roof, wall === ID.planks ? ID.planks : wall);
			for (let y = roof + 1; y < floor; y++) {
				if (!(x === x0 || x === x1)) {
					this.setFg(x, y, 0);
					this.setBg(x, y, ID.wallpaper);
					continue;
				}
				if (x === doorX && (y === floor - 1 || y === floor - 2)) {
					this.setFg(x, y, ID.door);
					this.setBg(x, y, ID.wallpaper);
				} else this.setFg(x, y, wall);
			}
		}
	}
	buildCottage(x0, floor) {
		const x1 = x0 + 9;
		const roof = floor - 6;
		this.carveRoom(x0, x1, floor, roof, ID.planks, x0);
		this.setFg(x1, floor - 2, ID.glass);
		this.setFg(x1, floor - 3, ID.glass);
		this.setFg(x1 - 1, roof - 1, ID.brick);
		this.setFg(x1 - 1, roof - 2, ID.brick);
		for (let y = roof - 1; y < floor; y++) this.setFg(x1 + 1, y, ID.ladder);
		this.setFg(x0 + 7, floor - 1, ID.bed);
		this.setFg(x0 + 2, floor - 1, ID.chest);
		this.setFg(x0 + 6, floor - 1, ID.table);
		this.setFg(x0 + 2, floor - 3, ID.torch);
		this.setFg(x1 - 2, floor - 1, ID.bookshelf);
		if (this.getFg(x0 - 2, floor) === ID.grass) this.setFg(x0 - 2, floor - 1, ID.flower);
	}
	buildRoom(x0, floor) {
		const x1 = x0 + 7;
		const roof = floor - 5;
		this.carveRoom(x0, x1, floor, roof, ID.stonebrick, x0);
		this.setFg(x1, floor - 2, ID.glass);
		this.setFg(x1, floor - 3, ID.glass);
		for (let x = x0 + 1; x < x1; x++) this.setBg(x, floor - 1, ID.bgWood);
		this.setFg(x0 + 5, floor - 1, ID.bed);
		this.setFg(x0 + 2, floor - 1, ID.chest);
		this.setFg(x0 + 3, floor - 3, ID.torch);
		this.setFg(x1 - 2, floor - 1, ID.furnace);
	}
	unstuck() {
		for (let i = 0; i < 12; i++) {
			if (!this.overlapsSolid(this.player.x, this.player.y, this.player.w, this.player.h)) return;
			this.player.y -= .15;
		}
	}
	overlapsSolid(x, y, w, h) {
		const x0 = Math.floor(x);
		const x1 = Math.floor(x + w - 1e-4);
		const y0 = Math.floor(y);
		const y1 = Math.floor(y + h - 1e-4);
		for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) if (this.solid(this.getFg(tx, ty))) return true;
		return false;
	}
	load() {
		try {
			const raw = localStorage.getItem(SAVE_KEY);
			if (!raw) return false;
			const data = JSON.parse(raw);
			if (data.v !== 1) return false;
			const fg = unb64(data.fg);
			const bg = unb64(data.bg);
			if (fg.length !== this.fg.length || bg.length !== this.bg.length) return false;
			this.fg = fg;
			this.bg = bg;
			this.seed = data.seed;
			this.player.x = data.x;
			this.player.y = data.y;
			this.player.facing = data.facing === -1 ? -1 : 1;
			this.flying = !!data.flying;
			this.recomputeAll();
			this.unstuck();
			return true;
		} catch {
			return false;
		}
	}
	queueSave() {
		this.saveTimer = .4;
	}
	save() {
		const blob = {
			v: 1,
			seed: this.seed,
			fg: b64(this.fg),
			bg: b64(this.bg),
			x: this.player.x,
			y: this.player.y,
			facing: this.player.facing,
			flying: this.flying
		};
		try {
			localStorage.setItem(SAVE_KEY, JSON.stringify(blob));
		} catch {}
	}
	emitHud(force = false) {
		const x = Math.floor(this.player.x);
		const y = Math.floor(this.player.y);
		if (force || this.frame % 8 === 0) this.onHud?.(x, y, this.flying);
	}
	effectiveKeys() {
		return this.forced ?? this.keys;
	}
	sampleEdges() {
		this.prevKeys = new Set(this.effectiveKeys());
		this.prevJump = this.effectiveKeys().has("Space") || this.touch.jump || !this.flying && (this.effectiveKeys().has("KeyW") || this.effectiveKeys().has("ArrowUp") || this.touch.up);
	}
	step(dt) {
		const now = this.effectiveKeys();
		const left = now.has("KeyA") || now.has("ArrowLeft") || this.touch.left;
		const right = now.has("KeyD") || now.has("ArrowRight") || this.touch.right;
		const upKey = now.has("KeyW") || now.has("ArrowUp") || this.touch.up;
		const downKey = now.has("KeyS") || now.has("ArrowDown") || this.touch.down;
		const jumpHeld = now.has("Space") || this.touch.jump || !this.flying && upKey;
		const jumpEdge = jumpHeld && !this.prevJump;
		if (now.has("KeyF") && !this.prevKeys.has("KeyF")) this.toggleFly();
		if (this.ui.current.started && now.has("Escape") && !this.prevKeys.has("Escape")) this.onPauseToggle?.();
		for (let n = 1; n <= 9; n++) {
			const code = `Digit${n}`;
			if (now.has(code) && !this.prevKeys.has(code)) {
				const id = this.ui.current.slots[n - 1];
				if (id) this.onSlot?.(id);
			}
		}
		const moveX = (right ? 1 : 0) - (left ? 1 : 0);
		if (moveX !== 0) this.player.facing = moveX;
		const p = this.player;
		const onLadder = this.touching((b) => !!b?.climb);
		const inWater = this.touching((b) => !!b?.liquid);
		if (jumpEdge) this.jumpBuffer = .14;
		else this.jumpBuffer = Math.max(0, this.jumpBuffer - dt);
		if (this.flying) {
			const moveY = (downKey ? 1 : 0) - (upKey || now.has("Space") || this.touch.jump ? 1 : 0);
			p.vx = approach(p.vx, moveX * 7.2, 48 * dt);
			p.vy = approach(p.vy, moveY * 7.2, 48 * dt);
			p.grounded = false;
		} else if (onLadder) {
			p.vx = approach(p.vx, moveX * 3.3, 36 * dt);
			if (upKey || jumpHeld) p.vy = -4.6;
			else if (downKey) p.vy = 5;
			else p.vy = 0;
			p.grounded = false;
			this.coyote = 0;
		} else if (inWater) {
			p.vx = approach(p.vx, moveX * 3.1, 14 * dt);
			p.vy = Math.min(4.2, p.vy + 10 * dt);
			if (jumpHeld) p.vy = Math.max(p.vy, -4.4);
			if (jumpEdge) p.vy = -5.2;
			p.grounded = false;
		} else {
			const speed = 5.8;
			const accel = p.grounded ? 52 : 24;
			p.vx = approach(p.vx, moveX * speed, accel * dt);
			if (moveX === 0) p.vx = approach(p.vx, 0, (p.grounded ? 42 : 8) * dt);
			p.vy = Math.min(16, p.vy + 34 * dt);
			if (this.jumpBuffer > 0 && (p.grounded || this.coyote > 0)) {
				p.vy = -10.4;
				p.grounded = false;
				this.coyote = 0;
				this.jumpBuffer = 0;
				this.sfx.unlock();
				this.sfx.jump();
			}
		}
		p.grounded = false;
		const steps = Math.max(1, Math.ceil((Math.abs(p.vx) + Math.abs(p.vy)) * dt / .35));
		const sdt = dt / steps;
		for (let i = 0; i < steps; i++) {
			p.x += p.vx * sdt;
			this.resolve("x");
			p.y += p.vy * sdt;
			this.resolve("y");
		}
		if (p.x < .05) {
			p.x = .05;
			p.vx = 0;
		}
		if (p.x + p.w > 279.95) {
			p.x = 280 - p.w - .05;
			p.vx = 0;
		}
		if (p.grounded) this.coyote = .12;
		else this.coyote = Math.max(0, this.coyote - dt);
		if (Math.abs(p.vx) > .2 && p.grounded) this.anim += dt * 10;
		this.holdPlace = Math.max(0, this.holdPlace - dt);
		this.holdBreak = Math.max(0, this.holdBreak - dt);
		if (now.has("KeyE") && this.holdPlace <= 0) {
			this.editAhead("place");
			this.holdPlace = .12;
		}
		if (now.has("KeyQ") && this.holdBreak <= 0) {
			this.editAhead("break");
			this.holdBreak = .12;
		}
		for (const particle of this.particles) {
			particle.life -= dt;
			particle.vy += 18 * dt;
			particle.x += particle.vx * dt;
			particle.y += particle.vy * dt;
		}
		if (this.particles.length > 140) this.particles.splice(0, this.particles.length - 140);
		this.particles = this.particles.filter((particle) => particle.life > 0);
		if (this.saveTimer > 0) {
			this.saveTimer -= dt;
			if (this.saveTimer <= 0) this.save();
		}
		this.prevKeys = new Set(now);
		this.prevJump = jumpHeld;
		this.frame++;
		this.emitHud(false);
		this.sfx.muted = this.ui.current.muted;
	}
	touching(pred) {
		const p = this.player;
		const x0 = Math.floor(p.x);
		const x1 = Math.floor(p.x + p.w - 1e-4);
		const y0 = Math.floor(p.y);
		const y1 = Math.floor(p.y + p.h - 1e-4);
		for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) if (pred(blockAt(this.getFg(x, y)))) return true;
		return false;
	}
	resolve(axis) {
		const p = this.player;
		const x0 = Math.floor(p.x);
		const x1 = Math.floor(p.x + p.w - 1e-4);
		const y0 = Math.floor(p.y);
		const y1 = Math.floor(p.y + p.h - 1e-4);
		if (axis === "x") {
			if (p.vx > 0) {
				for (let y = y0; y <= y1; y++) if (this.solid(this.getFg(x1, y))) {
					p.x = x1 - p.w;
					p.vx = 0;
					return;
				}
			} else if (p.vx < 0) {
				for (let y = y0; y <= y1; y++) if (this.solid(this.getFg(x0, y))) {
					p.x = x0 + 1;
					p.vx = 0;
					return;
				}
			}
		} else if (p.vy > 0) {
			for (let x = x0; x <= x1; x++) if (this.solid(this.getFg(x, y1))) {
				p.y = y1 - p.h;
				p.vy = 0;
				p.grounded = true;
				return;
			}
		} else if (p.vy < 0) {
			for (let x = x0; x <= x1; x++) if (this.solid(this.getFg(x, y0))) {
				p.y = y0 + 1;
				p.vy = 0;
				return;
			}
		}
	}
	reach(tx, ty) {
		const cx = this.player.x + this.player.w / 2;
		const cy = this.player.y + this.player.h / 2;
		const dx = tx + .5 - cx;
		const dy = ty + .5 - cy;
		return dx * dx + dy * dy <= 6.6 * 6.6;
	}
	overlapsPlayer(tx, ty) {
		const p = this.player;
		return tx + 1 > p.x && tx < p.x + p.w && ty + 1 > p.y && ty < p.y + p.h;
	}
	burst(tx, ty, color) {
		for (let i = 0; i < 7; i++) this.particles.push({
			x: tx + .2 + Math.random() * .6,
			y: ty + .2 + Math.random() * .6,
			vx: (Math.random() - .5) * 4,
			vy: -Math.random() * 4,
			life: .35 + Math.random() * .25,
			color,
			s: 2 + Math.random() * 2 | 0
		});
		this.shake = Math.min(2.2, this.shake + 1.2);
	}
	editCell(tx, ty, mode) {
		if (!this.inBounds(tx, ty) || !this.reach(tx, ty)) return false;
		if (mode === "break") {
			const fg = this.getFg(tx, ty);
			const block = blockAt(fg);
			if (fg !== 0 && block && !block.unbreakable) {
				this.setFg(tx, ty, 0);
				this.burst(tx, ty, block.color);
				this.sfx.unlock();
				this.sfx.break();
				this.queueSave();
				return true;
			}
			const bg = this.getBg(tx, ty);
			const wall = blockAt(bg);
			if (bg !== 0 && wall) {
				this.setBg(tx, ty, 0);
				this.burst(tx, ty, wall.color);
				this.sfx.unlock();
				this.sfx.break();
				this.queueSave();
				return true;
			}
			return false;
		}
		const chosen = blockAt(this.ui.current.blockId);
		if (!chosen) return false;
		if (chosen.background) {
			if (this.getBg(tx, ty) === chosen.id) return false;
			this.setBg(tx, ty, chosen.id);
			this.sfx.unlock();
			this.sfx.place();
			this.queueSave();
			return true;
		}
		if (this.getFg(tx, ty) !== 0) return false;
		if (chosen.solid && this.overlapsPlayer(tx, ty)) return false;
		this.setFg(tx, ty, chosen.id);
		this.burst(tx, ty, chosen.color);
		this.sfx.unlock();
		this.sfx.place();
		this.queueSave();
		return true;
	}
	editAhead(mode) {
		const tx = Math.floor(this.player.x + (this.player.facing > 0 ? this.player.w + .05 : -.05));
		const ty = Math.floor(this.player.y + this.player.h * .42);
		if (this.editCell(tx, ty, mode)) return {
			x: tx,
			y: ty
		};
		if (mode === "break") {
			const gy = Math.floor(this.player.y + this.player.h + .02);
			if (this.editCell(tx, gy, mode)) return {
				x: tx,
				y: gy
			};
		}
		return null;
	}
	paintPointer(clientX, clientY, mode) {
		const rect = this.canvas.getBoundingClientRect();
		if (rect.width < 1 || rect.height < 1) return;
		const ix = (clientX - rect.left) / rect.width * this.iw;
		const iy = (clientY - rect.top) / rect.height * this.ih;
		const originX = Math.round(this.camX * TILE);
		const originY = Math.round(this.camY * TILE);
		const tx = Math.floor((ix + originX) / TILE);
		const ty = Math.floor((iy + originY) / TILE);
		this.aim = {
			x: tx,
			y: ty
		};
		const key = `${tx}:${ty}:${mode}`;
		if (key === this.lastPaint) return;
		this.lastPaint = key;
		this.editCell(tx, ty, mode);
	}
	pickAt(clientX, clientY) {
		const rect = this.canvas.getBoundingClientRect();
		const ix = (clientX - rect.left) / rect.width * this.iw;
		const iy = (clientY - rect.top) / rect.height * this.ih;
		const originX = Math.round(this.camX * TILE);
		const originY = Math.round(this.camY * TILE);
		const tx = Math.floor((ix + originX) / TILE);
		const ty = Math.floor((iy + originY) / TILE);
		const fg = this.getFg(tx, ty);
		const id = fg !== 0 ? fg : this.getBg(tx, ty);
		if (blockAt(id)?.hotbar) this.onPick?.(id);
	}
	snapCamera(instant) {
		const viewW = this.iw / TILE;
		const viewH = this.ih / TILE;
		const hudBias = this.ui.current.started ? viewH * (this.iw < 520 ? .12 : .06) : 0;
		let tx = this.player.x + this.player.w / 2 - viewW / 2;
		let ty = this.player.y + this.player.h / 2 - viewH * .42 + hudBias;
		tx = Math.max(0, Math.min(280 - viewW, tx));
		ty = Math.max(0, Math.min(100 - viewH, ty));
		if (instant) {
			this.camX = tx;
			this.camY = ty;
		} else {
			const k = 1 - Math.exp(-8 * (1 / 60));
			this.camX += (tx - this.camX) * k;
			this.camY += (ty - this.camY) * k;
		}
	}
	resize() {
		const rect = this.canvas.getBoundingClientRect();
		const dpr = Math.min(2, window.devicePixelRatio || 1);
		const zoom = rect.width < 760 ? 2 : 3;
		this.iw = Math.max(160, Math.floor(rect.width / zoom));
		this.ih = Math.max(140, Math.floor(rect.height / zoom));
		this.off.width = this.iw;
		this.off.height = this.ih;
		this.canvas.width = Math.max(1, Math.floor(rect.width * dpr));
		this.canvas.height = Math.max(1, Math.floor(rect.height * dpr));
	}
	render() {
		this.snapCamera(false);
		const ctx = this.octx;
		ctx.imageSmoothingEnabled = false;
		const sky = ctx.createLinearGradient(0, 0, 0, this.ih);
		sky.addColorStop(0, "#79c8f5");
		sky.addColorStop(.55, "#d7f3ff");
		sky.addColorStop(1, "#c8e6a8");
		ctx.fillStyle = "rgba(255,255,255,0.92)";
		for (const cloud of this.clouds) {
			const px = Math.round((cloud.x * TILE - originX * .35) % (this.iw + 80) - 20);
			const py = cloud.y * 4 - originY * .05;
			const w = cloud.w * 4;
			ctx.fillRect(px, py, w, 6);
			ctx.fillRect(px + 6, py - 4, w - 10, 6);
		}
		const x0 = Math.max(0, Math.floor(originX / TILE) - 1);
		const y0 = Math.max(0, Math.floor(originY / TILE) - 1);
		const x1 = Math.min(279, Math.floor((originX + this.iw) / TILE) + 1);
		const y1 = Math.min(99, Math.floor((originY + this.ih) / TILE) + 1);
		const torches = [];
		for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
			const sx = tx * TILE - originX;
			const sy = ty * TILE - originY;
			const wall = this.getBg(tx, ty);
			const fg = this.getFg(tx, ty);
			if (wall) this.drawTile(ctx, wall, sx, sy, tx, ty, true);
			if (fg) this.drawTile(ctx, fg, sx, sy, tx, ty, false);
			if (fg === ID.torch) torches.push({
				x: sx + 8,
				y: sy + 6
			});
			const lum = (this.light[this.idx(tx, ty)] ?? 255) / 255;
			if (lum < .98) {
				ctx.fillStyle = `rgba(12,16,28,${(1 - lum) * .88})`;
				ctx.fillRect(sx, sy, TILE, TILE);
			}
		}
		for (const torch of torches) {
			const glow = ctx.createRadialGradient(torch.x, torch.y, 1, torch.x, torch.y, 42);
			glow.addColorStop(0, "rgba(255,196,80,0.45)");
			glow.addColorStop(1, "rgba(255,170,40,0)");
			ctx.fillStyle = glow;
			ctx.fillRect(torch.x - 42, torch.y - 42, 84, 84);
		}
		if (this.aim && this.ui.current.started && !this.ui.current.paused) {
			const sx = this.aim.x * TILE - originX;
			const sy = this.aim.y * TILE - originY;
			const ok = this.reach(this.aim.x, this.aim.y);
			const mode = this.painting ?? this.ui.current.tool;
			if (ok && mode === "place") {
				const chosen = blockAt(this.ui.current.blockId);
				if (chosen && (this.getFg(this.aim.x, this.aim.y) === 0 || chosen.background)) {
					ctx.globalAlpha = .45;
					this.drawTile(ctx, chosen.id, sx, sy, this.aim.x, this.aim.y, chosen.background);
					ctx.globalAlpha = 1;
				}
			}
			ctx.strokeStyle = !ok ? "rgba(255,255,255,0.45)" : mode === "break" ? "#ff5d4a" : "#ffe27a";
			ctx.lineWidth = 1;
			ctx.strokeRect(sx + .5, sy + .5, 15, 15);
		}
		for (const particle of this.particles) {
			const sx = Math.round(particle.x * TILE - originX);
			const sy = Math.round(particle.y * TILE - originY);
			ctx.globalAlpha = Math.max(0, particle.life * 2);
			ctx.fillStyle = particle.color;
			ctx.fillRect(sx, sy, particle.s, particle.s);
			ctx.globalAlpha = 1;
		}
		this.drawPlayer(ctx, originX, originY);
		const shakeX = this.shake > .15 ? (this.frame % 2 * 2 - 1) * this.shake : 0;
		const shakeY = this.shake > .15 ? (this.frame % 3 - 1) * this.shake * .4 : 0;
		this.shake *= .86;
		this.ctx.imageSmoothingEnabled = false;
		this.ctx.setTransform(1, 0, 0, 1, 0, 0);
		this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
		this.ctx.drawImage(this.off, shakeX, shakeY, this.canvas.width, this.canvas.height);
	}
	drawTile(ctx, id, sx, sy, tx, ty, back) {
		const block = blockAt(id);
		if (!block) return;
		const flip = !back && (tx * 3 + ty * 5 & 1) === 1 && block.solid && !block.transparent && id !== ID.grass && id !== ID.log && id !== ID.planks && id !== ID.brick && id !== ID.stonebrick;
		if (this.atlas) {
			const a = id - 1;
			const col = a % 8;
			const row = Math.floor(a / 8);
			ctx.save();
			if (back) ctx.globalAlpha = Math.min(1, ctx.globalAlpha) * .95;
			if (flip) {
				ctx.translate(sx + TILE, sy);
				ctx.scale(-1, 1);
				ctx.drawImage(this.atlas, col * TILE, row * TILE, TILE, TILE, 0, 0, TILE, TILE);
			} else ctx.drawImage(this.atlas, col * TILE, row * TILE, TILE, TILE, sx, sy, TILE, TILE);
			ctx.restore();
		} else {
			ctx.fillStyle = block.color;
			ctx.globalAlpha = back ? .85 : block.liquid ? .75 : 1;
			ctx.fillRect(sx, sy, TILE, TILE);
			ctx.globalAlpha = 1;
		}
		if (id === ID.water && this.getFg(tx, ty - 1) !== ID.water) {
			const wobble = Math.floor(this.clock * 3 + tx) % 3 - 1;
			ctx.fillStyle = "rgba(230,248,255,0.55)";
			ctx.fillRect(sx, sy + 1 + wobble, TILE, 2);
		}
	}
	drawPlayer(ctx, originX, originY) {
		const p = this.player;
		const feetX = Math.round(p.x * TILE + p.w * TILE / 2 - originX);
		const feetY = Math.round((p.y + p.h) * TILE - originY);
		ctx.fillStyle = "rgba(20,40,20,0.28)";
		ctx.fillRect(feetX - 7, feetY - 2, 14, 3);
		const airborne = !p.grounded && !this.flying;
		const sheet = airborne || this.flying ? this.jumpSheet ?? this.walk : this.walk;
		let frame = 0;
		if (this.flying) frame = 2;
		else if (airborne) frame = p.vy < 0 ? 1 : 3;
		else if (Math.abs(p.vx) > .35) frame = Math.floor(this.anim) % 4;
		const bob = this.flying ? Math.round(Math.sin(this.clock * 8) * 2) : 0;
		if (sheet) {
			const dw = CELL_W;
			const dh = CELL_H;
			ctx.save();
			ctx.translate(feetX, feetY + bob);
			if (p.facing < 0) ctx.scale(-1, 1);
			ctx.drawImage(sheet, frame * CELL_W, 0, CELL_W, CELL_H, -Math.floor(dw / 2), -34, dw, dh);
			ctx.restore();
			return;
		}
		ctx.save();
		ctx.translate(feetX, feetY + bob);
		if (p.facing < 0) ctx.scale(-1, 1);
		ctx.fillStyle = "#6b3a22";
		ctx.fillRect(-6, -28, 12, 8);
		ctx.fillStyle = "#f0c09a";
		ctx.fillRect(-5, -24, 10, 8);
		ctx.fillStyle = "#1c1a18";
		ctx.fillRect(1, -22, 2, 2);
		ctx.fillStyle = "#2f8f86";
		ctx.fillRect(-5, -16, 10, 9);
		ctx.fillStyle = "#6b4228";
		ctx.fillRect(-5, -7, 4, 4);
		ctx.fillRect(1, -7, 4, 4);
		ctx.fillStyle = "#5aaa45";
		ctx.fillRect(-1, -30, 2, 3);
		ctx.restore();
	}
	async loadArt() {
		try {
			const [atlas, walk, jumpSheet] = await Promise.all([
				loadImage("/tiles/atlas.png"),
				loadImage("/sprites/walk.png"),
				loadImage("/sprites/jump.png")
			]);
			this.atlas = atlas;
			this.walk = walk;
			this.jumpSheet = jumpSheet;
		} catch {}
	}
	onKeyDown = (e) => {
		if ([
			"KeyA",
			"KeyD",
			"KeyW",
			"KeyS",
			"KeyF",
			"KeyE",
			"KeyQ",
			"ArrowLeft",
			"ArrowRight",
			"ArrowUp",
			"ArrowDown",
			"Space",
			"Escape"
		].includes(e.code) || e.code.startsWith("Digit")) e.preventDefault();
		this.keys.add(e.code);
	};
	onKeyUp = (e) => {
		this.keys.delete(e.code);
	};
	onBlur = () => {
		this.keys.clear();
		this.touch = {
			left: false,
			right: false,
			up: false,
			down: false,
			jump: false
		};
		this.painting = null;
	};
	onPointerDown = (e) => {
		if (!this.ui.current.started || this.ui.current.paused) return;
		this.sfx.unlock();
		if (e.button === 1) {
			e.preventDefault();
			this.pickAt(e.clientX, e.clientY);
			return;
		}
		const mode = e.pointerType === "mouse" ? e.button === 2 ? "break" : "place" : this.ui.current.tool;
		this.painting = mode;
		this.lastPaint = "";
		this.canvas.setPointerCapture(e.pointerId);
		this.paintPointer(e.clientX, e.clientY, mode);
	};
	onPointerMove = (e) => {
		if (!this.ui.current.started || this.ui.current.paused) return;
		if (this.painting) this.paintPointer(e.clientX, e.clientY, this.painting);
		else if (e.pointerType === "mouse") {
			const rect = this.canvas.getBoundingClientRect();
			const ix = (e.clientX - rect.left) / rect.width * this.iw;
			const iy = (e.clientY - rect.top) / rect.height * this.ih;
			const originX = Math.round(this.camX * TILE);
			const originY = Math.round(this.camY * TILE);
			this.aim = {
				x: Math.floor((ix + originX) / TILE),
				y: Math.floor((iy + originY) / TILE)
			};
		}
	};
	onPointerUp = () => {
		this.painting = null;
		this.lastPaint = "";
	};
	onContext = (e) => {
		e.preventDefault();
	};
	onWheel = (e) => {
		if (!this.ui.current.started) return;
		e.preventDefault();
		const slots = this.ui.current.slots;
		if (!slots.length) return;
		const id = slots[(Math.max(0, slots.indexOf(this.ui.current.blockId)) + (e.deltaY > 0 ? 1 : -1) + slots.length) % slots.length];
		if (id) this.onSlot?.(id);
	};
	onResize = () => {
		this.resize();
	};
	onHide = () => {
		if (document.visibilityState === "hidden") this.save();
		this.keys.clear();
	};
	probeSetKeys = (codes) => {
		this.forced = new Set(codes);
	};
	bind() {
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
		window.addEventListener("resize", this.onResize);
		document.addEventListener("visibilitychange", this.onHide);
		this.canvas.addEventListener("pointerdown", this.onPointerDown);
		this.canvas.addEventListener("pointermove", this.onPointerMove);
		this.canvas.addEventListener("pointerup", this.onPointerUp);
		this.canvas.addEventListener("pointercancel", this.onPointerUp);
		this.canvas.addEventListener("contextmenu", this.onContext);
		this.canvas.addEventListener("wheel", this.onWheel, { passive: false });
		const obs = new ResizeObserver(this.onResize);
		obs.observe(this.canvas);
		this.resizeObserver = obs;
	}
	resizeObserver = null;
	unbind() {
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
		window.removeEventListener("resize", this.onResize);
		document.removeEventListener("visibilitychange", this.onHide);
		this.canvas.removeEventListener("pointerdown", this.onPointerDown);
		this.canvas.removeEventListener("pointermove", this.onPointerMove);
		this.canvas.removeEventListener("pointerup", this.onPointerUp);
		this.canvas.removeEventListener("pointercancel", this.onPointerUp);
		this.canvas.removeEventListener("contextmenu", this.onContext);
		this.canvas.removeEventListener("wheel", this.onWheel);
		this.resizeObserver?.disconnect();
	}
	attachProbe() {
		window.__controlsTest = {
			getYaw: () => this.player.facing > 0 ? 0 : Math.PI,
			getSpeed: () => this.player.vx,
			getX: () => this.player.x,
			getY: () => this.player.y,
			isFlying: () => this.flying,
			setKeys: this.probeSetKeys
		};
		window.__blokyuva = {
			ready: true,
			getBlock: (x, y) => this.getFg(x, y),
			getBg: (x, y) => this.getBg(x, y),
			debugPlace: () => {
				const hit = this.editAhead("place");
				if (!hit) return null;
				return {
					...hit,
					id: this.getFg(hit.x, hit.y) || this.getBg(hit.x, hit.y)
				};
			},
			debugBreak: () => this.editAhead("break")
		};
	}
};
function Blokyuva() {
	const canvasRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const [started, setStarted] = (0, import_react.useState)(false);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const [flying, setFlying] = (0, import_react.useState)(false);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [tool, setTool] = (0, import_react.useState)("place");
	const [cat, setCat] = (0, import_react.useState)("yapi");
	const [blockId, setBlockId] = (0, import_react.useState)(ID.planks);
	const [hud, setHud] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const slots = (0, import_react.useMemo)(() => hotbar(cat).map((block) => block.id), [cat]);
	const ui = (0, import_react.useRef)({
		started: false,
		paused: false,
		muted: false,
		tool: "place",
		blockId: ID.planks,
		slots: []
	});
	ui.current = {
		started,
		paused,
		muted,
		tool,
		blockId,
		slots
	};
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const engine = new Engine(canvas, ui);
		engineRef.current = engine;
		engine.onHud = (x, y, fly) => {
			setHud((prev) => prev.x === x && prev.y === y ? prev : {
				x,
				y
			});
			setFlying((prev) => prev === fly ? prev : fly);
		};
		engine.onSlot = (id) => setBlockId(id);
		engine.onPick = (id) => {
			const block = blockAt(id);
			if (!block) return;
			setCat(block.category);
			setBlockId(id);
		};
		engine.onPauseToggle = () => setPaused((prev) => !prev);
		engine.start();
		return () => {
			engine.destroy();
			engineRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!slots.includes(blockId) && slots[0]) setBlockId(slots[0]);
	}, [slots, blockId]);
	const selected = blockAt(blockId);
	const hold = (key) => ({
		onPointerDown: (e) => {
			e.preventDefault();
			e.currentTarget.setPointerCapture(e.pointerId);
			engineRef.current?.setTouch(key, true);
		},
		onPointerUp: () => engineRef.current?.setTouch(key, false),
		onPointerCancel: () => engineRef.current?.setTouch(key, false),
		onLostPointerCapture: () => engineRef.current?.setTouch(key, false)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "game-root fixed inset-0 overflow-hidden bg-sky text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none"
			}),
			!started && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-center justify-center bg-ink/45 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "w-full max-w-md rounded-2xl border border-line bg-panel px-6 py-6 shadow-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-bold tracking-wide text-leaf",
							children: "2D blok dünyası"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 font-sans text-4xl font-extrabold text-cream",
							children: "Blokyuva"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-base leading-relaxed text-muted",
							children: "Çimen, taş ve tahtayla ev kur. Odaların içine duvar kağıdı döşe. Zıpla, merdivene tırman ya da uçuşu aç."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-1 text-sm leading-relaxed text-cream",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A D yürü · Boşluk zıpla · F uçuş" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Sol tık koyar, sağ tık siler, sürükleyerek boyarsın" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "E koy · Q sil · tekerlek blok değiştirir" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-5 w-full rounded-xl bg-clay px-4 py-3 text-lg font-extrabold text-ink",
							onClick: () => {
								engineRef.current?.unlock();
								setStarted(true);
							},
							children: "Oyuna gir"
						})
					]
				})
			}),
			started && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-2 p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto rounded-xl border border-line bg-panel/90 px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold text-muted",
						children: "Blokyuva"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-extrabold text-cream",
						children: [
							"x ",
							hud.x,
							" · y ",
							hud.y,
							flying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-clay",
								children: "Uçuş"
							}) : null
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": muted ? "Sesi aç" : "Sesi kapat",
						className: "grid h-11 w-11 place-items-center rounded-xl border border-line bg-panel text-cream",
						onClick: () => setMuted((prev) => !prev),
						children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { size: 18 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Duraklat",
						className: "grid h-11 w-11 place-items-center rounded-xl border border-line bg-panel text-cream",
						onClick: () => setPaused(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { size: 18 })
					})]
				})]
			}),
			started && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "hud-foot pb-safe absolute inset-x-0 bottom-0 z-10 flex flex-col gap-2 p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto",
						children: CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `shrink-0 rounded-full px-3 py-2 text-sm font-extrabold ${cat === item.id ? "bg-clay text-ink" : "bg-panel text-cream"}`,
							onClick: () => setCat(item.id),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-w-0 flex-1 gap-1 overflow-x-auto",
							children: hotbar(cat).map((block, index) => {
								const cell = atlasCell(block.id);
								const active = block.id === blockId;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": block.name,
									"aria-pressed": active,
									className: `tile-ico shrink-0 rounded-lg border ${active ? "border-clay" : "border-line"}`,
									style: cell ? { backgroundPosition: `${-cell.col * 48}px ${-cell.row * 48}px` } : void 0,
									onClick: () => setBlockId(block.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "sr-only",
										children: [
											index + 1,
											" ",
											block.name
										]
									})
								}, block.id);
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden shrink-0 flex-col gap-1 sm:flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex items-center gap-1 rounded-lg bg-panel px-2 py-2 text-xs font-extrabold text-cream",
								onClick: () => engineRef.current?.stamp("cottage"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { size: 14 }), " Kulübe"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex items-center gap-1 rounded-lg bg-panel px-2 py-2 text-xs font-extrabold text-cream",
								onClick: () => engineRef.current?.stamp("room"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " Oda"]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-sm font-extrabold text-cream",
							children: [selected?.name ?? "Blok", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "hint-desktop font-bold text-muted",
								children: [" ", "· sol tık koy, sağ tık sil, sürükle"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1 sm:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "rounded-lg bg-panel px-2 py-2 text-xs font-extrabold text-cream",
								onClick: () => engineRef.current?.stamp("cottage"),
								children: "Kulübe"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "rounded-lg bg-panel px-2 py-2 text-xs font-extrabold text-cream",
								onClick: () => engineRef.current?.stamp("room"),
								children: "Oda"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "touch-controls items-end justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Yukarı",
									className: "pad",
									...hold("up"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { size: 22 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Sola",
									className: "pad",
									...hold("left"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { size: 22 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Aşağı",
									className: "pad",
									...hold("down"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { size: 22 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Sağa",
									className: "pad",
									...hold("right"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 22 })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-label": "Uçuş",
									className: `pad ${flying ? "bg-clay text-ink" : ""}`,
									onClick: () => engineRef.current?.toggleFly(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bird, { size: 16 }), " Uç"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-label": "Koy",
									className: `pad ${tool === "place" ? "bg-clay text-ink" : ""}`,
									onClick: () => setTool("place"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 }), " Koy"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "pad col-span-2 h-14 font-extrabold",
									...hold("jump"),
									children: "Zıpla"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: `pad col-span-2 ${tool === "break" ? "bg-clay text-ink" : ""}`,
									onClick: () => setTool("break"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, { size: 16 }), " Sil"]
								})
							]
						})]
					})
				]
			}),
			started && paused && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-30 flex items-center justify-center bg-ink/55 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "w-full max-w-sm rounded-2xl border border-line bg-panel px-6 py-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-extrabold text-cream",
							children: "Duraklatıldı"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "Dünyan bu cihazda duruyor. Yeni dünya mevcut adayı siler."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-4 w-full rounded-xl bg-clay px-4 py-3 font-extrabold text-ink",
							onClick: () => setPaused(false),
							children: "Devam et"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "mt-2 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-line px-4 py-3 font-extrabold text-cream",
							onClick: () => {
								engineRef.current?.resetWorld();
								setFlying(false);
								setPaused(false);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 16 }), " Yeni dünya"]
						})
					]
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blokyuva, {});
}
//#endregion
export { Home as component };
