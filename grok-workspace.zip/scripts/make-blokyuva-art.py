#!/usr/bin/env python3
"""Crisp 16px Minecraft-like block atlas + pixelated hero frames.

Blocks are authored at native 16×16 (nearest-neighbor, no blur).
Hero frames are chroma-keyed from generated sheets and reduced to a
shared pixel grid so they stay sharp beside the tiles.
"""
from __future__ import annotations

import math
from pathlib import Path

from PIL import Image

ROOT = Path("/workspace")
TILE = 16
COLS = 8
ROWS = 4

# --- tiny helpers -----------------------------------------------------------

def rng(x: int, y: int, salt: int) -> int:
    n = (x * 374761393 + y * 668265263 + salt * 1442695041) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return (n ^ (n >> 16)) & 0xFF


def mix(a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))  # type: ignore[return-value]


def new() -> Image.Image:
    return Image.new("RGBA", (TILE, TILE), (0, 0, 0, 0))


def noise_fill(colors: list[tuple[int, int, int]], salt: int) -> Image.Image:
    im = new()
    px = im.load()
    n = len(colors)
    for y in range(TILE):
        for x in range(TILE):
            h = rng(x, y, salt)
            # biased toward the first colors
            if h < 150:
                c = colors[0]
            elif h < 210:
                c = colors[1]
            elif h < 240:
                c = colors[2 % n]
            else:
                c = colors[min(3, n - 1)]
            # slight neighbor break-up
            if rng(x, y, salt + 9) > 248:
                c = mix(c, (0, 0, 0), 0.25)
            px[x, y] = (*c, 255)
    return im


def grass() -> Image.Image:
    dirt_cols = [(138, 90, 52), (166, 112, 66), (112, 72, 40), (186, 140, 88)]
    im = noise_fill(dirt_cols, 11)
    px = im.load()
    greens = [(78, 158, 52), (96, 176, 60), (62, 132, 42), (118, 190, 72)]
    for x in range(TILE):
        lip = 4 + (rng(x, 0, 3) % 3)  # 4..6
        for y in range(lip):
            g = greens[rng(x, y, 5) % 4]
            if y == lip - 1 and rng(x, y, 8) > 180:
                g = mix(g, (138, 90, 52), 0.45)
            px[x, y] = (*g, 255)
        # occasional hanging blade
        if rng(x, 3, 4) > 200 and lip < TILE - 1:
            px[x, lip] = (*greens[rng(x, 9, 2) % 3], 255)
    return im


def log() -> Image.Image:
    im = new()
    px = im.load()
    bark = [(112, 72, 40), (92, 58, 32), (134, 88, 50), (74, 46, 26)]
    for y in range(TILE):
        for x in range(TILE):
            band = 0 if x % 5 < 2 else 1 if x % 5 < 4 else 2
            c = bark[band]
            if rng(x, y, 21) > 230:
                c = bark[3]
            if x in (3, 10) and rng(0, y, 22) > 140:
                c = (150, 104, 62)
            px[x, y] = (*c, 255)
    return im


def planks(colors: list[tuple[int, int, int]] | None = None, salt: int = 30) -> Image.Image:
    colors = colors or [(196, 154, 92), (176, 132, 74), (214, 176, 112), (120, 82, 46)]
    im = new()
    px = im.load()
    seams = [4, 11, 2, 9]
    for y in range(TILE):
        board = y // 4
        seam_x = seams[board % 4]
        for x in range(TILE):
            if y % 4 == 3:
                c = colors[3]
            elif x == seam_x:
                c = colors[3]
            else:
                j = rng(x, board, salt)
                c = colors[0] if j < 160 else colors[1] if j < 220 else colors[2]
            px[x, y] = (*c, 255)
    return im


def leaves() -> Image.Image:
    cols = [(58, 140, 48), (72, 162, 58), (40, 110, 36), (90, 176, 64)]
    im = noise_fill(cols, 41)
    px = im.load()
    # punch a few holes so sky/wallpaper shows through
    for y in range(TILE):
        for x in range(TILE):
            if rng(x, y, 44) > 232:
                px[x, y] = (0, 0, 0, 0)
            elif rng(x, y, 45) > 248:
                px[x, y] = (*cols[3], 255)
    return im


def brick() -> Image.Image:
    im = new()
    px = im.load()
    mortar = (214, 196, 176)
    bricks = [(176, 72, 54), (156, 58, 44), (196, 92, 68), (140, 50, 40)]
    for y in range(TILE):
        row = y // 4
        in_mortar = y % 4 == 3
        shift = 8 if row % 2 else 0
        for x in range(TILE):
            if in_mortar or (x + shift) % 8 == 7:
                px[x, y] = (*mortar, 255)
            else:
                c = bricks[rng(x // 2, row, 50) % 4]
                px[x, y] = (*c, 255)
    return im


def stonebrick() -> Image.Image:
    im = new()
    px = im.load()
    mortar = (92, 92, 96)
    stones = [(150, 150, 154), (132, 132, 136), (168, 168, 172), (118, 118, 122)]
    for y in range(TILE):
        row = y // 8
        in_m = y % 8 == 7
        shift = 8 if row % 2 else 0
        for x in range(TILE):
            if in_m or (x + shift) % 8 == 7:
                px[x, y] = (*mortar, 255)
            else:
                c = stones[rng(x, y, 60) % 3]
                if rng(x, y, 61) > 240:
                    c = stones[3]
                px[x, y] = (*c, 255)
    return im


def glass() -> Image.Image:
    im = new()
    px = im.load()
    for y in range(TILE):
        for x in range(TILE):
            edge = x == 0 or y == 0 or x == 15 or y == 15
            if edge:
                px[x, y] = (214, 236, 244, 230)
            elif x == y or x == y + 1:
                px[x, y] = (255, 255, 255, 150)
            else:
                px[x, y] = (186, 220, 236, 70)
    # corner glint
    px[2, 2] = (255, 255, 255, 210)
    px[3, 2] = (255, 255, 255, 140)
    return im


def wool(base: tuple[int, int, int], salt: int) -> Image.Image:
    light = mix(base, (255, 255, 255), 0.22)
    dark = mix(base, (0, 0, 0), 0.18)
    return noise_fill([base, light, dark, mix(base, (0, 0, 0), 0.28)], salt)


def door() -> Image.Image:
    im = new()
    px = im.load()
    frame = (92, 58, 32)
    panel = (164, 112, 64)
    panel_d = (132, 86, 46)
    for y in range(TILE):
        for x in range(TILE):
            px[x, y] = (*frame, 255)
    for y in range(2, 7):
        for x in range(3, 13):
            px[x, y] = (*(panel if y not in (2, 6) and x not in (3, 12) else panel_d), 255)
    for y in range(9, 14):
        for x in range(3, 13):
            px[x, y] = (*(panel if y not in (9, 13) and x not in (3, 12) else panel_d), 255)
    px[11, 8] = (212, 180, 64, 255)
    px[11, 9] = (180, 140, 40, 255)
    return im


def torch() -> Image.Image:
    im = new()
    px = im.load()
    for y in range(9, 16):
        px[7, y] = (92, 64, 36, 255)
        px[8, y] = (70, 48, 28, 255)
    flame = {
        (7, 3): (255, 244, 160, 255),
        (8, 3): (255, 220, 80, 255),
        (6, 4): (255, 176, 48, 255),
        (7, 4): (255, 236, 120, 255),
        (8, 4): (255, 200, 48, 255),
        (9, 4): (255, 140, 32, 255),
        (6, 5): (255, 120, 28, 255),
        (7, 5): (255, 210, 64, 255),
        (8, 5): (255, 160, 36, 255),
        (9, 5): (220, 80, 24, 255),
        (7, 6): (255, 140, 32, 255),
        (8, 6): (200, 70, 20, 255),
        (7, 7): (160, 60, 24, 255),
        (8, 7): (120, 48, 20, 255),
    }
    for (x, y), c in flame.items():
        px[x, y] = c
    return im


def flower() -> Image.Image:
    im = new()
    px = im.load()
    for y in range(8, 15):
        px[8, y] = (62, 130, 48, 255)
    px[7, 13] = (70, 150, 52, 255)
    px[9, 12] = (70, 150, 52, 255)
    petals = [(255, 92, 122), (255, 140, 160), (230, 60, 90)]
    for dx, dy in ((0, -2), (-1, -1), (1, -1), (-2, 0), (2, 0), (-1, 1), (1, 1), (0, 2)):
        px[8 + dx, 6 + dy] = (*petals[(dx + dy) & 1], 255) if not (dx == 0 and dy == 0) else (255, 220, 80, 255)
    px[8, 6] = (255, 214, 70, 255)
    return im


def bed() -> Image.Image:
    im = new()
    px = im.load()
    blanket = [(176, 48, 62), (196, 70, 82), (140, 36, 50)]
    for y in range(6, 16):
        for x in range(TILE):
            if y > 13:
                px[x, y] = (92, 58, 36, 255)  # frame
            elif x < 4:
                c = (236, 228, 214) if y < 12 else (200, 190, 176)
                px[x, y] = (*c, 255)
            else:
                c = blanket[0 if (x + y) % 5 else 1]
                if y == 6:
                    c = blanket[2]
                px[x, y] = (*c, 255)
    return im


def chest() -> Image.Image:
    im = new()
    px = im.load()
    body = (150, 96, 48)
    dark = (92, 58, 30)
    lid = (176, 118, 60)
    for y in range(TILE):
        for x in range(TILE):
            px[x, y] = (*dark, 255)
    for y in range(2, 7):
        for x in range(2, 14):
            px[x, y] = (*lid, 255)
    for y in range(8, 14):
        for x in range(2, 14):
            px[x, y] = (*body, 255)
    for x in range(6, 10):
        px[x, 7] = (212, 176, 64, 255)
    px[7, 10] = (212, 176, 64, 255)
    px[8, 10] = (180, 140, 40, 255)
    return im


def table() -> Image.Image:
    im = new()
    px = im.load()
    top = (186, 132, 74)
    leg = (112, 72, 40)
    for y in range(4, 8):
        for x in range(TILE):
            px[x, y] = (*(top if y > 4 else (150, 100, 56)), 255)
    for y in range(8, 16):
        for x in (2, 3, 12, 13):
            px[x, y] = (*leg, 255)
    return im


def ladder() -> Image.Image:
    im = new()
    px = im.load()
    rail = (120, 78, 42, 255)
    rung = (168, 120, 70, 255)
    for y in range(TILE):
        px[3, y] = rail
        px[4, y] = rail
        px[11, y] = rail
        px[12, y] = rail
        if y % 4 == 1:
            for x in range(4, 12):
                px[x, y] = rung
    return im


def bookshelf() -> Image.Image:
    im = planks()
    px = im.load()
    books = [
        (150, 48, 48),
        (48, 78, 150),
        (48, 130, 72),
        (180, 140, 48),
        (120, 60, 140),
        (40, 110, 120),
    ]
    for y in range(1, 15):
        if y % 4 == 3:
            continue
        for x in range(1, 15):
            px[x, y] = (*books[(x + y) % len(books)], 255)
    return im


def furnace() -> Image.Image:
    im = noise_fill([(120, 120, 124), (100, 100, 104), (140, 140, 144), (80, 80, 84)], 70)
    px = im.load()
    for y in range(4, 12):
        for x in range(4, 12):
            px[x, y] = (40, 40, 44, 255)
    for y in range(8, 11):
        for x in range(6, 10):
            px[x, y] = (255, 140, 40, 255) if y == 9 else (255, 200, 80, 255)
    return im


def wallpaper() -> Image.Image:
    im = new()
    px = im.load()
    base = (236, 222, 196)
    motif = (196, 112, 96)
    vine = (120, 156, 96)
    for y in range(TILE):
        for x in range(TILE):
            c = base
            if (x + y) % 8 == 0:
                c = motif
            elif (x % 8 == 2 and y % 8 > 2) or (y % 8 == 2 and x % 8 > 2):
                c = vine
            px[x, y] = (*c, 255)
    return im


def hay() -> Image.Image:
    im = new()
    px = im.load()
    cols = [(214, 176, 64), (186, 146, 42), (230, 198, 90), (150, 112, 36)]
    for y in range(TILE):
        for x in range(TILE):
            band = (x + y * 2) % 5
            c = cols[0 if band < 2 else 1 if band < 4 else 2]
            if rng(x, y, 80) > 230:
                c = cols[3]
            if y % 5 == 4:
                c = cols[3]
            px[x, y] = (*c, 255)
    return im


def bedrock() -> Image.Image:
    im = noise_fill([(36, 36, 40), (22, 22, 26), (54, 54, 58), (14, 14, 16)], 90)
    return im


def cobble() -> Image.Image:
    im = noise_fill([(130, 130, 134), (108, 108, 112), (150, 150, 154), (86, 86, 90)], 15)
    px = im.load()
    # dark grout cracks
    for y in range(TILE):
        for x in range(TILE):
            if rng(x // 3, y // 3, 16) < 18 or (x % 5 == 0 and rng(x, y, 17) > 180):
                px[x, y] = (72, 72, 76, 255)
    return im


def water() -> Image.Image:
    im = new()
    px = im.load()
    for y in range(TILE):
        for x in range(TILE):
            t = y / 15
            c = mix((92, 186, 224), (36, 110, 186), t)
            if rng(x, y, 99) > 220:
                c = mix(c, (255, 255, 255), 0.35)
            px[x, y] = (*c, 210)
    for x in range(TILE):
        px[x, 0] = (210, 240, 255, 230)
        px[x, 1] = (150, 210, 235, 200)
    return im


def build_atlas() -> Image.Image:
    tiles = [
        grass(),          # 0 çimen
        noise_fill([(142, 92, 54), (168, 114, 68), (112, 72, 42), (190, 142, 92)], 12),  # toprak
        noise_fill([(132, 132, 136), (112, 112, 116), (154, 154, 158), (90, 90, 94)], 13),  # taş
        cobble(),         # kırıktaş
        log(),
        planks(),
        leaves(),
        noise_fill([(228, 206, 150), (210, 186, 128), (240, 224, 176), (186, 160, 108)], 18),  # kum
        brick(),
        glass(),
        stonebrick(),
        wool((186, 64, 72), 101),
        wool((64, 112, 186), 102),
        wool((214, 176, 64), 103),
        wool((236, 236, 232), 104),
        wool((72, 150, 84), 105),
        door(),
        torch(),
        flower(),
        bed(),
        chest(),
        table(),
        ladder(),
        bookshelf(),
        furnace(),
        planks([(120, 86, 52), (104, 72, 42), (140, 104, 66), (72, 48, 30)], 31),  # arka tahta
        stonebrick(),  # will darken via copy below — arka taş drawn darker
        wallpaper(),
        bedrock(),
        hay(),
        wool((214, 120, 164), 106),
        water(),
    ]
    assert len(tiles) == COLS * ROWS, len(tiles)
    # darken background stone (index 26)
    bg_stone = tiles[26].copy()
    px = bg_stone.load()
    for y in range(TILE):
        for x in range(TILE):
            r, g, b, a = px[x, y]
            px[x, y] = (int(r * 0.62), int(g * 0.62), int(b * 0.66), a)
    tiles[26] = bg_stone

    atlas = Image.new("RGBA", (COLS * TILE, ROWS * TILE), (0, 0, 0, 0))
    for i, tile in enumerate(tiles):
        atlas.paste(tile, ((i % COLS) * TILE, (i // COLS) * TILE))
    return atlas


# --- hero -------------------------------------------------------------------

def is_magenta(r: int, g: int, b: int) -> bool:
    if r < 140 or b < 140:
        return False
    if g > 150:
        return False
    if abs(r - b) > 90:
        return False
    return (r + b) * 0.5 - g > 70


def key_magenta(im: Image.Image) -> Image.Image:
    im = im.convert("RGBA")
    px = im.load()
    w, h = im.size
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if is_magenta(r, g, b):
                px[x, y] = (0, 0, 0, 0)
    # fringe: pixels touching transparency that are still pink
    src = im.copy()
    sp = src.load()
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a == 0:
                continue
            touch = False
            for ny in (y - 1, y, y + 1):
                for nx in (x - 1, x, x + 1):
                    if 0 <= nx < w and 0 <= ny < h and sp[nx, ny][3] == 0:
                        touch = True
            if touch and r > 160 and b > 120 and g < 170 and r > g + 20 and b > g:
                px[x, y] = (0, 0, 0, 0)
            elif touch and r > 180 and b > 180 and g < 190:
                px[x, y] = (0, 0, 0, 0)
    return im


def content_bbox(im: Image.Image) -> tuple[int, int, int, int]:
    px = im.load()
    w, h = im.size
    minx, miny, maxx, maxy = w, h, 0, 0
    for y in range(h):
        for x in range(w):
            if px[x, y][3] > 20:
                minx = min(minx, x)
                miny = min(miny, y)
                maxx = max(maxx, x)
                maxy = max(maxy, y)
    if maxx < minx:
        return 0, 0, w, h
    return minx, miny, maxx + 1, maxy + 1


def split_grid(im: Image.Image, rows: int, cols: int) -> list[Image.Image]:
    w, h = im.size
    cw, ch = w // cols, h // rows
    out = []
    for r in range(rows):
        for c in range(cols):
            out.append(im.crop((c * cw, r * ch, (c + 1) * cw, (r + 1) * ch)))
    return out


def process_sheet(path: Path, cell_w: int = 32, cell_h: int = 40) -> Image.Image:
    raw = Image.open(path)
    keyed = key_magenta(raw)
    frames = split_grid(keyed, 2, 2)
    crops = []
    heights = []
    for fr in frames:
        b = content_bbox(fr)
        crop = fr.crop(b)
        crops.append(crop)
        heights.append(crop.size[1])
    target_h = 34
    # shared scale from the median height so one outlier doesn't shrink everyone
    heights_sorted = sorted(heights)
    ref_h = heights_sorted[len(heights_sorted) // 2]
    scale = target_h / ref_h
    sheet = Image.new("RGBA", (cell_w * 4, cell_h), (0, 0, 0, 0))
    for i, crop in enumerate(crops):
        tw = max(1, int(round(crop.size[0] * scale)))
        th = max(1, int(round(crop.size[1] * scale)))
        # box-filter down to the pixel grid, then it's drawn nearest-neighbor in game
        small = crop.resize((tw, th), Image.Resampling.BOX)
        # quantize rgb but keep alpha
        alpha = small.getchannel("A")
        rgb = small.convert("RGB").quantize(colors=20, method=Image.Quantize.MEDIANCUT).convert("RGB")
        small = rgb.convert("RGBA")
        small.putalpha(alpha)
        # hard alpha
        sp = small.load()
        for y in range(th):
            for x in range(tw):
                r, g, b, a = sp[x, y]
                if a < 40:
                    sp[x, y] = (0, 0, 0, 0)
                else:
                    sp[x, y] = (r, g, b, 255)
        ox = i * cell_w + (cell_w - tw) // 2
        oy = cell_h - 3 - th  # feet line
        sheet.alpha_composite(small, (ox, max(0, oy)))
    return sheet


def main() -> None:
    out_tiles = ROOT / "public" / "tiles"
    out_sprites = ROOT / "public" / "sprites"
    out_tiles.mkdir(parents=True, exist_ok=True)
    out_sprites.mkdir(parents=True, exist_ok=True)

    atlas = build_atlas()
    atlas.save(out_tiles / "atlas.png")
    preview = atlas.resize((atlas.width * 6, atlas.height * 6), Image.Resampling.NEAREST)
    preview.save(ROOT / "screenshots" / "atlas-preview.png")

    walk_src = ROOT / "artifacts/imagine_images/6299eb0f-da80-4736-84b7-7872d325bdcc.jpg"
    jump_src = ROOT / "artifacts/imagine_images/3fb232ce-a69c-4aeb-a30c-584d546b463a.jpg"
    walk = process_sheet(walk_src)
    jump = process_sheet(jump_src)
    walk.save(out_sprites / "walk.png")
    jump.save(out_sprites / "jump.png")
    hero_preview = Image.new("RGBA", (walk.width * 4, walk.height * 4 * 2 + 8), (40, 48, 64, 255))
    hero_preview.paste(walk.resize((walk.width * 4, walk.height * 4), Image.Resampling.NEAREST), (0, 0))
    hero_preview.paste(jump.resize((jump.width * 4, jump.height * 4), Image.Resampling.NEAREST), (0, walk.height * 4 + 8))
    hero_preview.save(ROOT / "screenshots" / "hero-preview.png")
    print("atlas", atlas.size, "walk", walk.size, "jump", jump.size)


if __name__ == "__main__":
    main()
