import { useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import {
  Bird,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Eraser,
  House,
  Pause,
  Plus,
  RotateCcw,
  Volume2,
  VolumeX,
} from "lucide-react";
import { CATEGORIES, ID, atlasCell, blockAt, hotbar, type Category } from "@/game/blocks";
import { Engine, type Tool, type UiSnap } from "@/game/engine";

export function Blokyuva() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [started, setStarted] = useState(false);
  const [paused, setPaused] = useState(false);
  const [flying, setFlying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [tool, setTool] = useState<Tool>("place");
  const [cat, setCat] = useState<Category>("yapi");
  const [blockId, setBlockId] = useState<number>(ID.planks);
  const [hud, setHud] = useState({ x: 0, y: 0 });
  const slots = useMemo(() => hotbar(cat).map((block) => block.id), [cat]);
  const ui = useRef<UiSnap>({
    started: false,
    paused: false,
    muted: false,
    tool: "place",
    blockId: ID.planks,
    slots: [],
  });
  ui.current = { started, paused, muted, tool, blockId, slots };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new Engine(canvas, ui);
    engineRef.current = engine;
    engine.onHud = (x, y, fly) => {
      setHud((prev) => (prev.x === x && prev.y === y ? prev : { x, y }));
      setFlying((prev) => (prev === fly ? prev : fly));
    };
    engine.onSlot = (id) => setBlockId(id);
    engine.onPick = (id) => {
      const block = blockAt(id);
      if (!block) return;
      setCat(block.category);
      setBlockId(id);
    };
    engine.onPauseToggle = () => setPaused((prev) => !prev);
    engine.start();
    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!slots.includes(blockId) && slots[0]) setBlockId(slots[0]);
  }, [slots, blockId]);

  const selected = blockAt(blockId);
  const hold = (key: "left" | "right" | "up" | "down" | "jump") => ({
    onPointerDown: (e: ReactPointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      e.currentTarget.setPointerCapture(e.pointerId);
      engineRef.current?.setTouch(key, true);
    },
    onPointerUp: () => engineRef.current?.setTouch(key, false),
    onPointerCancel: () => engineRef.current?.setTouch(key, false),
    onLostPointerCapture: () => engineRef.current?.setTouch(key, false),
  });

  return (
    <main className="game-root fixed inset-0 overflow-hidden bg-sky text-cream">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />

      {!started && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-ink/45 p-4">
          <section className="w-full max-w-md rounded-2xl border border-line bg-panel px-6 py-6 shadow-xl">
            <p className="text-sm font-bold tracking-wide text-leaf">2D blok dünyası</p>
            <h1 className="mt-1 font-sans text-4xl font-extrabold text-cream">Blokyuva</h1>
            <p className="mt-2 text-base leading-relaxed text-muted">
              Çimen, taş ve tahtayla ev kur. Odaların içine duvar kağıdı döşe. Zıpla, merdivene tırman
              ya da uçuşu aç.
            </p>
            <ul className="mt-4 space-y-1 text-sm leading-relaxed text-cream">
              <li>A D yürü · Boşluk zıpla · F uçuş</li>
              <li>Sol tık koyar, sağ tık siler, sürükleyerek boyarsın</li>
              <li>E koy · Q sil · tekerlek blok değiştirir</li>
            </ul>
            <button
              type="button"
              className="mt-5 w-full rounded-xl bg-clay px-4 py-3 text-lg font-extrabold text-ink"
              onClick={() => {
                engineRef.current?.unlock();
                setStarted(true);
              }}
            >
              Oyuna gir
            </button>
          </section>
        </div>
      )}

      {started && (
        <header className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-2 p-3">
          <div className="pointer-events-auto rounded-xl border border-line bg-panel/90 px-3 py-2">
            <p className="text-xs font-bold text-muted">Blokyuva</p>
            <p className="font-extrabold text-cream">
              x {hud.x} · y {hud.y}
              {flying ? <span className="ml-2 text-clay">Uçuş</span> : null}
            </p>
          </div>
          <div className="pointer-events-auto flex gap-2">
            <button
              type="button"
              aria-label={muted ? "Sesi aç" : "Sesi kapat"}
              className="grid h-11 w-11 place-items-center rounded-xl border border-line bg-panel text-cream"
              onClick={() => setMuted((prev) => !prev)}
            >
              {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
            </button>
            <button
              type="button"
              aria-label="Duraklat"
              className="grid h-11 w-11 place-items-center rounded-xl border border-line bg-panel text-cream"
              onClick={() => setPaused(true)}
            >
              <Pause size={18} />
            </button>
          </div>
        </header>
      )}

      {started && (
        <footer className="hud-foot pb-safe absolute inset-x-0 bottom-0 z-10 flex flex-col gap-2 p-2">
          <div className="flex gap-2 overflow-x-auto">
            {CATEGORIES.map((item) => (
              <button
                key={item.id}
                type="button"
                className={`shrink-0 rounded-full px-3 py-2 text-sm font-extrabold ${
                  cat === item.id ? "bg-clay text-ink" : "bg-panel text-cream"
                }`}
                onClick={() => setCat(item.id)}
              >
                {item.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <div className="flex min-w-0 flex-1 gap-1 overflow-x-auto">
              {hotbar(cat).map((block, index) => {
                const cell = atlasCell(block.id);
                const active = block.id === blockId;
                return (
                  <button
                    key={block.id}
                    type="button"
                    aria-label={block.name}
                    aria-pressed={active}
                    className={`tile-ico shrink-0 rounded-lg border ${
                      active ? "border-clay" : "border-line"
                    }`}
                    style={
                      cell
                        ? { backgroundPosition: `${-cell.col * 48}px ${-cell.row * 48}px` }
                        : undefined
                    }
                    onClick={() => setBlockId(block.id)}
                  >
                    <span className="sr-only">
                      {index + 1} {block.name}
                    </span>
                  </button>
                );
              })}
            </div>
            <div className="hidden shrink-0 flex-col gap-1 sm:flex">
              <button
                type="button"
                className="inline-flex items-center gap-1 rounded-lg bg-panel px-2 py-2 text-xs font-extrabold text-cream"
                onClick={() => engineRef.current?.stamp("cottage")}
              >
                <House size={14} /> Kulübe
              </button>
              <button
                type="button"
                className="inline-flex items-center gap-1 rounded-lg bg-panel px-2 py-2 text-xs font-extrabold text-cream"
                onClick={() => engineRef.current?.stamp("room")}
              >
                <Plus size={14} /> Oda
              </button>
            </div>
          </div>
          <div className="flex items-center justify-between gap-2">
            <p className="truncate text-sm font-extrabold text-cream">
              {selected?.name ?? "Blok"}
              <span className="hint-desktop font-bold text-muted">
                {" "}
                · sol tık koy, sağ tık sil, sürükle
              </span>
            </p>
            <div className="flex gap-1 sm:hidden">
              <button
                type="button"
                className="rounded-lg bg-panel px-2 py-2 text-xs font-extrabold text-cream"
                onClick={() => engineRef.current?.stamp("cottage")}
              >
                Kulübe
              </button>
              <button
                type="button"
                className="rounded-lg bg-panel px-2 py-2 text-xs font-extrabold text-cream"
                onClick={() => engineRef.current?.stamp("room")}
              >
                Oda
              </button>
            </div>
          </div>
          <div className="touch-controls items-end justify-between gap-2">
            <div className="grid grid-cols-3 gap-1">
              <span />
              <button type="button" aria-label="Yukarı" className="pad" {...hold("up")}>
                <ChevronUp size={22} />
              </button>
              <span />
              <button type="button" aria-label="Sola" className="pad" {...hold("left")}>
                <ChevronLeft size={22} />
              </button>
              <button type="button" aria-label="Aşağı" className="pad" {...hold("down")}>
                <ChevronDown size={22} />
              </button>
              <button type="button" aria-label="Sağa" className="pad" {...hold("right")}>
                <ChevronRight size={22} />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-1">
              <button
                type="button"
                aria-label="Uçuş"
                className={`pad ${flying ? "bg-clay text-ink" : ""}`}
                onClick={() => engineRef.current?.toggleFly()}
              >
                <Bird size={16} /> Uç
              </button>
              <button
                type="button"
                aria-label="Koy"
                className={`pad ${tool === "place" ? "bg-clay text-ink" : ""}`}
                onClick={() => setTool("place")}
              >
                <Plus size={18} /> Koy
              </button>
              <button type="button" className="pad col-span-2 h-14 font-extrabold" {...hold("jump")}>
                Zıpla
              </button>
              <button
                type="button"
                className={`pad col-span-2 ${tool === "break" ? "bg-clay text-ink" : ""}`}
                onClick={() => setTool("break")}
              >
                <Eraser size={16} /> Sil
              </button>
            </div>
          </div>
        </footer>
      )}

      {started && paused && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-ink/55 p-4">
          <section className="w-full max-w-sm rounded-2xl border border-line bg-panel px-6 py-6">
            <h2 className="text-2xl font-extrabold text-cream">Duraklatıldı</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              Dünyan bu cihazda duruyor. Yeni dünya mevcut adayı siler.
            </p>
            <button
              type="button"
              className="mt-4 w-full rounded-xl bg-clay px-4 py-3 font-extrabold text-ink"
              onClick={() => setPaused(false)}
            >
              Devam et
            </button>
            <button
              type="button"
              className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-line px-4 py-3 font-extrabold text-cream"
              onClick={() => {
                engineRef.current?.resetWorld();
                setFlying(false);
                setPaused(false);
              }}
            >
              <RotateCcw size={16} /> Yeni dünya
            </button>
          </section>
        </div>
      )}
    </main>
  );
}
