import { Sfx } from "@/game/audio";
import { AIR, ATLAS_COLS, ID, blockAt, type BlockDef } from "@/game/blocks";

export const WORLD_W = 280;
export const WORLD_H = 100;
const TILE = 16;
const SAVE_KEY = "blokyuva-save-v1";
const CELL_W = 28;
const CELL_H = 36;

export type Tool = "place" | "break";

export type UiSnap = {
  started: boolean;
  paused: boolean;
  muted: boolean;
  tool: Tool;
  blockId: number;
  slots: number[];
};

type TouchState = { left: boolean; right: boolean; up: boolean; down: boolean; jump: boolean };

type Particle = { x: number; y: number; vx: number; vy: number; life: number; color: string; s: number };

type SaveBlob = {
  v: 1;
  seed: number;
  fg: string;
  bg: string;
  x: number;
  y: number;
  facing: number;
  flying: boolean;
};

export type ControlsProbe = {
  getYaw: () => number;
  getSpeed: () => number;
  getX: () => number;
  getY: () => number;
  isFlying: () => boolean;
  setKeys: (codes: string[]) => void;
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
    __blokyuva?: {
      ready: boolean;
      getBlock: (x: number, y: number) => number;
      getBg: (x: number, y: number) => number;
      debugPlace: () => { x: number; y: number; id: number } | null;
      debugBreak: () => { x: number; y: number } | null;
    };
  }
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function approach(v: number, target: number, max: number) {
  if (v < target) return Math.min(target, v + max);
  return Math.max(target, v - max);
}

function b64(bytes: Uint8Array) {
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i] ?? 0);
  return btoa(s);
}

function unb64(text: string) {
  const bin = atob(text);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(src));
    img.src = src;
  });
}

export class Engine {
  readonly canvas: HTMLCanvasElement;
  private readonly ui: { current: UiSnap };
  private readonly ctx: CanvasRenderingContext2D;
  private readonly off: HTMLCanvasElement;
  private readonly octx: CanvasRenderingContext2D;
  private readonly sfx = new Sfx();
  private readonly keys = new Set<string>();
  private prevKeys = new Set<string>();
  private forced: Set<string> | null = null;
  private touch: TouchState = { left: false, right: false, up: false, down: false, jump: false };
  private prevJump = false;
  private raf = 0;
  private last = 0;
  private acc = 0;
  private frame = 0;
  private iw = 320;
  private ih = 180;
  private camX = 0;
  private camY = 0;
  private anim = 0;
  private coyote = 0;
  private jumpBuffer = 0;
  private holdPlace = 0;
  private holdBreak = 0;
  private shake = 0;
  private clock = 0;
  private saveTimer = 0;
  private painting: Tool | null = null;
  private lastPaint = "";
  private aim: { x: number; y: number } | null = null;
  flying = false;
  private fg = new Uint8Array(WORLD_W * WORLD_H);
  private bg = new Uint8Array(WORLD_W * WORLD_H);
  private light = new Uint8Array(WORLD_W * WORLD_H);
  private seed = 1;
  private particles: Particle[] = [];
  private atlas: HTMLImageElement | null = null;
  private walk: HTMLImageElement | null = null;
  private jumpSheet: HTMLImageElement | null = null;
  private clouds: { x: number; y: number; w: number; s: number }[] = [];
  player = { x: 8, y: 8, w: 0.62, h: 1.72, vx: 0, vy: 0, facing: 1, grounded: false };
  onHud: ((x: number, y: number, flying: boolean) => void) | null = null;
  onSlot: ((id: number) => void) | null = null;
  onPauseToggle: (() => void) | null = null;
  onPick: ((id: number) => void) | null = null;

  constructor(canvas: HTMLCanvasElement, ui: { current: UiSnap }) {
    this.canvas = canvas;
    this.ui = ui;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("canvas");
    this.ctx = ctx;
    this.off = document.createElement("canvas");
    const octx = this.off.getContext("2d");
    if (!octx) throw new Error("offscreen");
    this.octx = octx;
    if (!this.load()) this.generate(false);
    this.resize();
    this.snapCamera(true);
    this.bind();
    this.attachProbe();
    void this.loadArt();
    for (let i = 0; i < 7; i++) {
      this.clouds.push({
        x: (i * 47) % WORLD_W,
        y: 4 + (i % 3) * 3,
        w: 6 + (i % 4),
        s: 0.4 + (i % 3) * 0.15,
      });
    }
  }

  start() {
    this.last = performance.now();
    const loop = (t: number) => {
      const dt = Math.min(0.05, (t - this.last) / 1000 || 0);
      this.last = t;
      this.clock += dt;
      const sim = this.ui.current.started && !this.ui.current.paused;
      if (sim) {
        this.acc += dt;
        let guard = 0;
        while (this.acc >= 1 / 60 && guard++ < 5) {
          this.step(1 / 60);
          this.acc -= 1 / 60;
        }
      } else {
        this.acc = 0;
        this.sampleEdges();
      }
      this.render();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.unbind();
    if (window.__controlsTest?.setKeys === this.probeSetKeys) delete window.__controlsTest;
    delete window.__blokyuva;
  }

  setTouch(key: keyof TouchState, down: boolean) {
    this.touch[key] = down;
    if (down) this.sfx.unlock();
  }

  toggleFly() {
    this.flying = !this.flying;
    if (this.flying) this.player.vy = 0;
    this.sfx.unlock();
    this.sfx.fly(this.flying);
    this.emitHud(true);
    this.queueSave();
  }

  unlock() {
    this.sfx.unlock();
  }

  stamp(kind: "cottage" | "room") {
    const floor = Math.floor(this.player.y + this.player.h + 0.001);
    const px = Math.floor(this.player.x);
    const width = kind === "cottage" ? 10 : 8;
    let x0 = px + (this.player.facing > 0 ? 2 : -(width + 1));
    x0 = Math.max(2, Math.min(WORLD_W - width - 2, x0));
    if (kind === "cottage") this.buildCottage(x0, floor);
    else this.buildRoom(x0, floor);
    this.queueSave();
  }

  resetWorld() {
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch {
      /* ignore */
    }
    this.generate(true);
    this.flying = false;
    this.particles = [];
    this.snapCamera(true);
    this.emitHud(true);
  }

  private idx(x: number, y: number) {
    return y * WORLD_W + x;
  }

  private inBounds(x: number, y: number) {
    return x >= 0 && y >= 0 && x < WORLD_W && y < WORLD_H;
  }

  private getFg(x: number, y: number) {
    if (!this.inBounds(x, y)) return ID.bedrock;
    return this.fg[this.idx(x, y)] ?? AIR;
  }

  private getBg(x: number, y: number) {
    if (!this.inBounds(x, y)) return AIR;
    return this.bg[this.idx(x, y)] ?? AIR;
  }

  private solid(id: number) {
    return blockAt(id)?.solid ?? false;
  }

  private setFg(x: number, y: number, id: number) {
    if (!this.inBounds(x, y)) return false;
    if (this.fg[this.idx(x, y)] === ID.bedrock) return false;
    this.fg[this.idx(x, y)] = id;
    this.recomputeColumn(x);
    return true;
  }

  private setBg(x: number, y: number, id: number) {
    if (!this.inBounds(x, y)) return false;
    this.bg[this.idx(x, y)] = id;
    return true;
  }

  private recomputeColumn(x: number) {
    let sun = 255;
    for (let y = 0; y < WORLD_H; y++) {
      const i = this.idx(x, y);
      this.light[i] = sun;
      const block = blockAt(this.fg[i] ?? 0);
      if (!block) continue;
      if (block.liquid) sun = Math.max(110, sun - 30);
      else if (block.transparent && block.solid) sun = Math.max(150, sun - 28);
      else if (block.solid) sun = Math.max(58, sun - 78);
    }
  }

  private recomputeAll() {
    for (let x = 0; x < WORLD_W; x++) this.recomputeColumn(x);
  }

  private generate(forceNew: boolean) {
    this.seed = forceNew ? (Math.random() * 1e9) | 0 : 0x51a7c0de;
    const rand = mulberry32(this.seed);
    this.fg.fill(0);
    this.bg.fill(0);
    const surface = (x: number) => {
      const n =
        Math.sin(x * 0.045 + this.seed * 0.00001) * 5 +
        Math.sin(x * 0.013 + this.seed * 0.000002) * 8 +
        Math.sin(x * 0.1 + 2) * 1.5;
      return Math.max(22, Math.min(72, Math.floor(38 + n)));
    };
    const waterLine = 46;
    for (let x = 0; x < WORLD_W; x++) {
      const s0 = surface(x);
      const lake = s0 > waterLine;
      const top = lake ? waterLine : s0;
      for (let y = 0; y < WORLD_H; y++) {
        if (y >= WORLD_H - 2) {
          this.fg[this.idx(x, y)] = ID.bedrock;
          continue;
        }
        if (lake && y >= waterLine && y < s0) {
          this.fg[this.idx(x, y)] = ID.water;
          continue;
        }
        if (y < top) continue;
        const depth = y - (lake ? s0 : top);
        let id: number = ID.stone;
        if (!lake && depth === 0) id = ID.grass;
        else if (lake && y < s0 + 4) id = ID.sand;
        else if (!lake && depth < 4 + (x % 3)) id = ID.dirt;
        else id = ID.stone;
        const cave =
          y > top + 6 &&
          Math.sin(x * 0.21 + this.seed) + Math.sin(y * 0.27) + Math.sin((x + y) * 0.11) > 1.72;
        this.fg[this.idx(x, y)] = cave ? AIR : id;
      }
    }
    for (let x = 4; x < WORLD_W - 4; x++) {
      const s = surface(x);
      if (s >= waterLine - 1) continue;
      const flat = Math.abs(surface(x - 1) - s) < 2 && Math.abs(surface(x + 1) - s) < 2;
      if (!flat) continue;
      if (rand() < 0.09) {
        const h = 4 + (rand() * 3) | 0;
        const base = s - 1;
        for (let i = 0; i < h; i++) this.fg[this.idx(x, base - i)] = ID.log;
        const crown = base - h + 1;
        for (let dy = -2; dy <= 1; dy++) {
          for (let dx = -2; dx <= 2; dx++) {
            if (Math.abs(dx) + Math.abs(dy) > 3) continue;
            const tx = x + dx;
            const ty = crown + dy;
            if (this.inBounds(tx, ty) && this.fg[this.idx(tx, ty)] === AIR) {
              this.fg[this.idx(tx, ty)] = ID.leaves;
            }
          }
        }
      } else if (rand() < 0.05) {
        this.fg[this.idx(x, s - 1)] = ID.flower;
      } else if (rand() < 0.02) {
        this.fg[this.idx(x, s - 1)] = ID.cobble;
      }
    }

    let spawnX = 70;
    for (let x = 40; x < 140; x++) {
      if (surface(x) < waterLine - 2 && Math.abs(surface(x) - surface(x + 12)) <= 1) {
        spawnX = x;
        break;
      }
    }
    const floor = surface(spawnX);
    for (let x = spawnX - 8; x <= spawnX + 18; x++) {
      if (!this.inBounds(x, floor)) continue;
      for (let y = 0; y < floor; y++) this.fg[this.idx(x, y)] = AIR;
      if (this.fg[this.idx(x, floor)] !== ID.bedrock) this.fg[this.idx(x, floor)] = ID.grass;
    }
    this.buildCottage(spawnX + 5, floor);
    this.player.x = spawnX + 0.4;
    this.player.y = floor - this.player.h;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.facing = 1;
    this.player.grounded = true;
    this.recomputeAll();
    this.unstuck();
  }

  private carveRoom(
    x0: number,
    x1: number,
    floor: number,
    roof: number,
    wall: number,
    doorX: number,
  ) {
    for (let x = x0; x <= x1; x++) {
      this.setFg(x, floor, ID.planks);
      this.setFg(x, roof, wall === ID.planks ? ID.planks : wall);
      for (let y = roof + 1; y < floor; y++) {
        const edge = x === x0 || x === x1;
        if (!edge) {
          this.setFg(x, y, AIR);
          this.setBg(x, y, ID.wallpaper);
          continue;
        }
        if (x === doorX && (y === floor - 1 || y === floor - 2)) {
          this.setFg(x, y, ID.door);
          this.setBg(x, y, ID.wallpaper);
        } else {
          this.setFg(x, y, wall);
        }
      }
    }
  }

  private buildCottage(x0: number, floor: number) {
    const x1 = x0 + 9;
    const roof = floor - 6;
    this.carveRoom(x0, x1, floor, roof, ID.planks, x0);
    this.setFg(x1, floor - 2, ID.glass);
    this.setFg(x1, floor - 3, ID.glass);
    this.setFg(x1 - 1, roof - 1, ID.brick);
    this.setFg(x1 - 1, roof - 2, ID.brick);
    for (let y = roof - 1; y < floor; y++) this.setFg(x1 + 1, y, ID.ladder);
    this.setFg(x0 + 7, floor - 1, ID.bed);
    this.setFg(x0 + 2, floor - 1, ID.chest);
    this.setFg(x0 + 6, floor - 1, ID.table);
    this.setFg(x0 + 2, floor - 3, ID.torch);
    this.setFg(x1 - 2, floor - 1, ID.bookshelf);
    if (this.getFg(x0 - 2, floor) === ID.grass) this.setFg(x0 - 2, floor - 1, ID.flower);
  }

  private buildRoom(x0: number, floor: number) {
    const x1 = x0 + 7;
    const roof = floor - 5;
    this.carveRoom(x0, x1, floor, roof, ID.stonebrick, x0);
    this.setFg(x1, floor - 2, ID.glass);
    this.setFg(x1, floor - 3, ID.glass);
    for (let x = x0 + 1; x < x1; x++) this.setBg(x, floor - 1, ID.bgWood);
    this.setFg(x0 + 5, floor - 1, ID.bed);
    this.setFg(x0 + 2, floor - 1, ID.chest);
    this.setFg(x0 + 3, floor - 3, ID.torch);
    this.setFg(x1 - 2, floor - 1, ID.furnace);
  }

  private unstuck() {
    for (let i = 0; i < 12; i++) {
      if (!this.overlapsSolid(this.player.x, this.player.y, this.player.w, this.player.h)) return;
      this.player.y -= 0.15;
    }
  }

  private overlapsSolid(x: number, y: number, w: number, h: number) {
    const x0 = Math.floor(x);
    const x1 = Math.floor(x + w - 1e-4);
    const y0 = Math.floor(y);
    const y1 = Math.floor(y + h - 1e-4);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (this.solid(this.getFg(tx, ty))) return true;
      }
    }
    return false;
  }

  private load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return false;
      const data = JSON.parse(raw) as SaveBlob;
      if (data.v !== 1) return false;
      const fg = unb64(data.fg);
      const bg = unb64(data.bg);
      if (fg.length !== this.fg.length || bg.length !== this.bg.length) return false;
      this.fg = fg;
      this.bg = bg;
      this.seed = data.seed;
      this.player.x = data.x;
      this.player.y = data.y;
      this.player.facing = data.facing === -1 ? -1 : 1;
      this.flying = !!data.flying;
      this.recomputeAll();
      this.unstuck();
      return true;
    } catch {
      return false;
    }
  }

  private queueSave() {
    this.saveTimer = 0.4;
  }

  private save() {
    const blob: SaveBlob = {
      v: 1,
      seed: this.seed,
      fg: b64(this.fg),
      bg: b64(this.bg),
      x: this.player.x,
      y: this.player.y,
      facing: this.player.facing,
      flying: this.flying,
    };
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(blob));
    } catch {
      /* ignore quota */
    }
  }

  private emitHud(force = false) {
    const x = Math.floor(this.player.x);
    const y = Math.floor(this.player.y);
    if (force || this.frame % 8 === 0) this.onHud?.(x, y, this.flying);
  }

  private effectiveKeys() {
    return this.forced ?? this.keys;
  }

  private sampleEdges() {
    this.prevKeys = new Set(this.effectiveKeys());
    this.prevJump =
      this.effectiveKeys().has("Space") ||
      this.touch.jump ||
      (!this.flying &&
        (this.effectiveKeys().has("KeyW") ||
          this.effectiveKeys().has("ArrowUp") ||
          this.touch.up));
  }

  private step(dt: number) {
    const now = this.effectiveKeys();
    const left = now.has("KeyA") || now.has("ArrowLeft") || this.touch.left;
    const right = now.has("KeyD") || now.has("ArrowRight") || this.touch.right;
    const upKey = now.has("KeyW") || now.has("ArrowUp") || this.touch.up;
    const downKey = now.has("KeyS") || now.has("ArrowDown") || this.touch.down;
    const jumpHeld = now.has("Space") || this.touch.jump || (!this.flying && upKey);
    const jumpEdge = jumpHeld && !this.prevJump;
    if (now.has("KeyF") && !this.prevKeys.has("KeyF")) this.toggleFly();
    if (this.ui.current.started && now.has("Escape") && !this.prevKeys.has("Escape")) {
      this.onPauseToggle?.();
    }
    for (let n = 1; n <= 9; n++) {
      const code = `Digit${n}`;
      if (now.has(code) && !this.prevKeys.has(code)) {
        const id = this.ui.current.slots[n - 1];
        if (id) this.onSlot?.(id);
      }
    }
    const moveX = (right ? 1 : 0) - (left ? 1 : 0);
    if (moveX !== 0) this.player.facing = moveX;

    const p = this.player;
    const onLadder = this.touching((b) => !!b?.climb);
    const inWater = this.touching((b) => !!b?.liquid);

    if (jumpEdge) this.jumpBuffer = 0.14;
    else this.jumpBuffer = Math.max(0, this.jumpBuffer - dt);

    if (this.flying) {
      const moveY = (downKey ? 1 : 0) - (upKey || now.has("Space") || this.touch.jump ? 1 : 0);
      p.vx = approach(p.vx, moveX * 7.2, 48 * dt);
      p.vy = approach(p.vy, moveY * 7.2, 48 * dt);
      p.grounded = false;
    } else if (onLadder) {
      p.vx = approach(p.vx, moveX * 3.3, 36 * dt);
      if (upKey || jumpHeld) p.vy = -4.6;
      else if (downKey) p.vy = 5;
      else p.vy = 0;
      p.grounded = false;
      this.coyote = 0;
    } else if (inWater) {
      p.vx = approach(p.vx, moveX * 3.1, 14 * dt);
      p.vy = Math.min(4.2, p.vy + 10 * dt);
      if (jumpHeld) p.vy = Math.max(p.vy, -4.4);
      if (jumpEdge) p.vy = -5.2;
      p.grounded = false;
    } else {
      const speed = 5.8;
      const accel = p.grounded ? 52 : 24;
      p.vx = approach(p.vx, moveX * speed, accel * dt);
      if (moveX === 0) p.vx = approach(p.vx, 0, (p.grounded ? 42 : 8) * dt);
      p.vy = Math.min(16, p.vy + 34 * dt);
      if (this.jumpBuffer > 0 && (p.grounded || this.coyote > 0)) {
        p.vy = -10.4;
        p.grounded = false;
        this.coyote = 0;
        this.jumpBuffer = 0;
        this.sfx.unlock();
        this.sfx.jump();
      }
    }

    p.grounded = false;
    const steps = Math.max(1, Math.ceil((Math.abs(p.vx) + Math.abs(p.vy)) * dt / 0.35));
    const sdt = dt / steps;
    for (let i = 0; i < steps; i++) {
      p.x += p.vx * sdt;
      this.resolve("x");
      p.y += p.vy * sdt;
      this.resolve("y");
    }
    if (p.x < 0.05) {
      p.x = 0.05;
      p.vx = 0;
    }
    if (p.x + p.w > WORLD_W - 0.05) {
      p.x = WORLD_W - p.w - 0.05;
      p.vx = 0;
    }
    if (p.grounded) this.coyote = 0.12;
    else this.coyote = Math.max(0, this.coyote - dt);

    if (Math.abs(p.vx) > 0.2 && p.grounded) this.anim += dt * 10;
    this.holdPlace = Math.max(0, this.holdPlace - dt);
    this.holdBreak = Math.max(0, this.holdBreak - dt);
    if (now.has("KeyE") && this.holdPlace <= 0) {
      this.editAhead("place");
      this.holdPlace = 0.12;
    }
    if (now.has("KeyQ") && this.holdBreak <= 0) {
      this.editAhead("break");
      this.holdBreak = 0.12;
    }

    for (const particle of this.particles) {
      particle.life -= dt;
      particle.vy += 18 * dt;
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
    }
    if (this.particles.length > 140) this.particles.splice(0, this.particles.length - 140);
    this.particles = this.particles.filter((particle) => particle.life > 0);

    if (this.saveTimer > 0) {
      this.saveTimer -= dt;
      if (this.saveTimer <= 0) this.save();
    }
    this.prevKeys = new Set(now);
    this.prevJump = jumpHeld;
    this.frame++;
    this.emitHud(false);
    this.sfx.muted = this.ui.current.muted;
  }

  private touching(pred: (b: BlockDef | null) => boolean) {
    const p = this.player;
    const x0 = Math.floor(p.x);
    const x1 = Math.floor(p.x + p.w - 1e-4);
    const y0 = Math.floor(p.y);
    const y1 = Math.floor(p.y + p.h - 1e-4);
    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        if (pred(blockAt(this.getFg(x, y)))) return true;
      }
    }
    return false;
  }

  private resolve(axis: "x" | "y") {
    const p = this.player;
    const x0 = Math.floor(p.x);
    const x1 = Math.floor(p.x + p.w - 1e-4);
    const y0 = Math.floor(p.y);
    const y1 = Math.floor(p.y + p.h - 1e-4);
    if (axis === "x") {
      if (p.vx > 0) {
        for (let y = y0; y <= y1; y++) {
          if (this.solid(this.getFg(x1, y))) {
            p.x = x1 - p.w;
            p.vx = 0;
            return;
          }
        }
      } else if (p.vx < 0) {
        for (let y = y0; y <= y1; y++) {
          if (this.solid(this.getFg(x0, y))) {
            p.x = x0 + 1;
            p.vx = 0;
            return;
          }
        }
      }
    } else if (p.vy > 0) {
      for (let x = x0; x <= x1; x++) {
        if (this.solid(this.getFg(x, y1))) {
          p.y = y1 - p.h;
          p.vy = 0;
          p.grounded = true;
          return;
        }
      }
    } else if (p.vy < 0) {
      for (let x = x0; x <= x1; x++) {
        if (this.solid(this.getFg(x, y0))) {
          p.y = y0 + 1;
          p.vy = 0;
          return;
        }
      }
    }
  }

  private reach(tx: number, ty: number) {
    const cx = this.player.x + this.player.w / 2;
    const cy = this.player.y + this.player.h / 2;
    const dx = tx + 0.5 - cx;
    const dy = ty + 0.5 - cy;
    return dx * dx + dy * dy <= 6.6 * 6.6;
  }

  private overlapsPlayer(tx: number, ty: number) {
    const p = this.player;
    return tx + 1 > p.x && tx < p.x + p.w && ty + 1 > p.y && ty < p.y + p.h;
  }

  private burst(tx: number, ty: number, color: string) {
    for (let i = 0; i < 7; i++) {
      this.particles.push({
        x: tx + 0.2 + Math.random() * 0.6,
        y: ty + 0.2 + Math.random() * 0.6,
        vx: (Math.random() - 0.5) * 4,
        vy: -Math.random() * 4,
        life: 0.35 + Math.random() * 0.25,
        color,
        s: 2 + (Math.random() * 2) | 0,
      });
    }
    this.shake = Math.min(2.2, this.shake + 1.2);
  }

  private editCell(tx: number, ty: number, mode: Tool) {
    if (!this.inBounds(tx, ty) || !this.reach(tx, ty)) return false;
    if (mode === "break") {
      const fg = this.getFg(tx, ty);
      const block = blockAt(fg);
      if (fg !== AIR && block && !block.unbreakable) {
        this.setFg(tx, ty, AIR);
        this.burst(tx, ty, block.color);
        this.sfx.unlock();
        this.sfx.break();
        this.queueSave();
        return true;
      }
      const bg = this.getBg(tx, ty);
      const wall = blockAt(bg);
      if (bg !== AIR && wall) {
        this.setBg(tx, ty, AIR);
        this.burst(tx, ty, wall.color);
        this.sfx.unlock();
        this.sfx.break();
        this.queueSave();
        return true;
      }
      return false;
    }
    const chosen = blockAt(this.ui.current.blockId);
    if (!chosen) return false;
    if (chosen.background) {
      if (this.getBg(tx, ty) === chosen.id) return false;
      this.setBg(tx, ty, chosen.id);
      this.sfx.unlock();
      this.sfx.place();
      this.queueSave();
      return true;
    }
    if (this.getFg(tx, ty) !== AIR) return false;
    if (chosen.solid && this.overlapsPlayer(tx, ty)) return false;
    this.setFg(tx, ty, chosen.id);
    this.burst(tx, ty, chosen.color);
    this.sfx.unlock();
    this.sfx.place();
    this.queueSave();
    return true;
  }

  private editAhead(mode: Tool) {
    const tx =
      this.player.facing > 0
        ? Math.floor(this.player.x + this.player.w - 1e-4) + 1
        : Math.floor(this.player.x) - 1;
    const ty = Math.floor(this.player.y + this.player.h * 0.45);
    if (this.editCell(tx, ty, mode)) return { x: tx, y: ty };
    if (mode === "break") {
      const gy = Math.floor(this.player.y + this.player.h + 0.02);
      if (this.editCell(tx, gy, mode)) return { x: tx, y: gy };
    }
    if (mode === "place" && this.editCell(tx, ty + 1, mode)) return { x: tx, y: ty + 1 };
    return null;
  }

  private paintPointer(clientX: number, clientY: number, mode: Tool) {
    const rect = this.canvas.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) return;
    const ix = ((clientX - rect.left) / rect.width) * this.iw;
    const iy = ((clientY - rect.top) / rect.height) * this.ih;
    const originX = Math.round(this.camX * TILE);
    const originY = Math.round(this.camY * TILE);
    const tx = Math.floor((ix + originX) / TILE);
    const ty = Math.floor((iy + originY) / TILE);
    this.aim = { x: tx, y: ty };
    const key = `${tx}:${ty}:${mode}`;
    if (key === this.lastPaint) return;
    this.lastPaint = key;
    this.editCell(tx, ty, mode);
  }

  private pickAt(clientX: number, clientY: number) {
    const rect = this.canvas.getBoundingClientRect();
    const ix = ((clientX - rect.left) / rect.width) * this.iw;
    const iy = ((clientY - rect.top) / rect.height) * this.ih;
    const originX = Math.round(this.camX * TILE);
    const originY = Math.round(this.camY * TILE);
    const tx = Math.floor((ix + originX) / TILE);
    const ty = Math.floor((iy + originY) / TILE);
    const fg = this.getFg(tx, ty);
    const id = fg !== AIR ? fg : this.getBg(tx, ty);
    const block = blockAt(id);
    if (block?.hotbar) this.onPick?.(id);
  }

  private snapCamera(instant: boolean) {
    const viewW = this.iw / TILE;
    const viewH = this.ih / TILE;
    const hudBias = this.ui.current.started ? viewH * (this.iw < 520 ? 0.12 : 0.06) : 0;
    let tx = this.player.x + this.player.w / 2 - viewW / 2;
    let ty = this.player.y + this.player.h / 2 - viewH * 0.42 + hudBias;
    tx = Math.max(0, Math.min(WORLD_W - viewW, tx));
    ty = Math.max(0, Math.min(WORLD_H - viewH, ty));
    if (instant) {
      this.camX = tx;
      this.camY = ty;
    } else {
      const k = 1 - Math.exp(-8 * (1 / 60));
      this.camX += (tx - this.camX) * k;
      this.camY += (ty - this.camY) * k;
    }
  }

  private resize() {
    const rect = this.canvas.getBoundingClientRect();
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const zoom = rect.width < 760 ? 2 : 3;
    this.iw = Math.max(160, Math.floor(rect.width / zoom));
    this.ih = Math.max(140, Math.floor(rect.height / zoom));
    this.off.width = this.iw;
    this.off.height = this.ih;
    this.canvas.width = Math.max(1, Math.floor(rect.width * dpr));
    this.canvas.height = Math.max(1, Math.floor(rect.height * dpr));
  }

  private render() {
    this.snapCamera(false);
    const ctx = this.octx;
    ctx.imageSmoothingEnabled = false;
    const sky = ctx.createLinearGradient(0, 0, 0, this.ih);
    sky.addColorStop(0, "#79c8f5");
    sky.addColorStop(0.55, "#d7f3ff");
    sky.addColorStop(1, "#c8e6a8");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, this.iw, this.ih);

    const originX = Math.round(this.camX * TILE);
    const originY = Math.round(this.camY * TILE);
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    const span = this.iw + 80;
    for (const cloud of this.clouds) {
      const raw = cloud.x * TILE - originX * 0.35;
      const px = Math.round((((raw % span) + span) % span) - 20);
      const py = cloud.y * 4 - originY * 0.05;
      const w = cloud.w * 4;
      ctx.fillRect(px, py, w, 6);
      ctx.fillRect(px + 6, py - 4, w - 10, 6);
    }

    const x0 = Math.max(0, Math.floor(originX / TILE) - 1);
    const y0 = Math.max(0, Math.floor(originY / TILE) - 1);
    const x1 = Math.min(WORLD_W - 1, Math.floor((originX + this.iw) / TILE) + 1);
    const y1 = Math.min(WORLD_H - 1, Math.floor((originY + this.ih) / TILE) + 1);
    const torches: { x: number; y: number }[] = [];

    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        const sx = tx * TILE - originX;
        const sy = ty * TILE - originY;
        const wall = this.getBg(tx, ty);
        const fg = this.getFg(tx, ty);
        if (wall) this.drawTile(ctx, wall, sx, sy, tx, ty, true);
        if (fg) this.drawTile(ctx, fg, sx, sy, tx, ty, false);
        if (fg === ID.torch) torches.push({ x: sx + 8, y: sy + 6 });
        const lum = (this.light[this.idx(tx, ty)] ?? 255) / 255;
        if (lum < 0.98) {
          ctx.fillStyle = `rgba(12,16,28,${(1 - lum) * 0.88})`;
          ctx.fillRect(sx, sy, TILE, TILE);
        }
      }
    }

    for (const torch of torches) {
      const glow = ctx.createRadialGradient(torch.x, torch.y, 1, torch.x, torch.y, 42);
      glow.addColorStop(0, "rgba(255,196,80,0.45)");
      glow.addColorStop(1, "rgba(255,170,40,0)");
      ctx.fillStyle = glow;
      ctx.fillRect(torch.x - 42, torch.y - 42, 84, 84);
    }

    if (this.aim && this.ui.current.started && !this.ui.current.paused) {
      const sx = this.aim.x * TILE - originX;
      const sy = this.aim.y * TILE - originY;
      const ok = this.reach(this.aim.x, this.aim.y);
      const mode = this.painting ?? this.ui.current.tool;
      if (ok && mode === "place") {
        const chosen = blockAt(this.ui.current.blockId);
        if (chosen && (this.getFg(this.aim.x, this.aim.y) === AIR || chosen.background)) {
          ctx.globalAlpha = 0.45;
          this.drawTile(ctx, chosen.id, sx, sy, this.aim.x, this.aim.y, chosen.background);
          ctx.globalAlpha = 1;
        }
      }
      ctx.strokeStyle = !ok ? "rgba(255,255,255,0.45)" : mode === "break" ? "#ff5d4a" : "#ffe27a";
      ctx.lineWidth = 1;
      ctx.strokeRect(sx + 0.5, sy + 0.5, TILE - 1, TILE - 1);
    }

    for (const particle of this.particles) {
      const sx = Math.round(particle.x * TILE - originX);
      const sy = Math.round(particle.y * TILE - originY);
      ctx.globalAlpha = Math.max(0, particle.life * 2);
      ctx.fillStyle = particle.color;
      ctx.fillRect(sx, sy, particle.s, particle.s);
      ctx.globalAlpha = 1;
    }

    this.drawPlayer(ctx, originX, originY);

    const shakeX = this.shake > 0.15 ? ((this.frame % 2) * 2 - 1) * this.shake : 0;
    const shakeY = this.shake > 0.15 ? ((this.frame % 3) - 1) * this.shake * 0.4 : 0;
    this.shake *= 0.86;
    this.ctx.imageSmoothingEnabled = false;
    this.ctx.setTransform(1, 0, 0, 1, 0, 0);
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.drawImage(this.off, shakeX, shakeY, this.canvas.width, this.canvas.height);
  }

  private drawTile(
    ctx: CanvasRenderingContext2D,
    id: number,
    sx: number,
    sy: number,
    tx: number,
    ty: number,
    back: boolean,
  ) {
    const block = blockAt(id);
    if (!block) return;
    const flip = !back && ((tx * 3 + ty * 5) & 1) === 1 && block.solid && !block.transparent && id !== ID.grass && id !== ID.log && id !== ID.planks && id !== ID.brick && id !== ID.stonebrick;
    if (this.atlas) {
      const a = id - 1;
      const col = a % ATLAS_COLS;
      const row = Math.floor(a / ATLAS_COLS);
      ctx.save();
      if (back) ctx.globalAlpha = Math.min(1, ctx.globalAlpha) * 0.95;
      if (flip) {
        ctx.translate(sx + TILE, sy);
        ctx.scale(-1, 1);
        ctx.drawImage(this.atlas, col * TILE, row * TILE, TILE, TILE, 0, 0, TILE, TILE);
      } else {
        ctx.drawImage(this.atlas, col * TILE, row * TILE, TILE, TILE, sx, sy, TILE, TILE);
      }
      ctx.restore();
    } else {
      ctx.fillStyle = block.color;
      ctx.globalAlpha = back ? 0.85 : block.liquid ? 0.75 : 1;
      ctx.fillRect(sx, sy, TILE, TILE);
      ctx.globalAlpha = 1;
    }
    if (id === ID.water && this.getFg(tx, ty - 1) !== ID.water) {
      const wobble = (Math.floor(this.clock * 3 + tx) % 3) - 1;
      ctx.fillStyle = "rgba(230,248,255,0.55)";
      ctx.fillRect(sx, sy + 1 + wobble, TILE, 2);
    }
  }

  private drawPlayer(ctx: CanvasRenderingContext2D, originX: number, originY: number) {
    const p = this.player;
    const feetX = Math.round(p.x * TILE + (p.w * TILE) / 2 - originX);
    const feetY = Math.round((p.y + p.h) * TILE - originY);
    ctx.fillStyle = "rgba(20,40,20,0.28)";
    ctx.fillRect(feetX - 7, feetY - 2, 14, 3);
    const airborne = !p.grounded && !this.flying;
    const sheet = airborne || this.flying ? this.jumpSheet ?? this.walk : this.walk;
    let frame = 0;
    if (this.flying) frame = 2;
    else if (airborne) frame = p.vy < 0 ? 1 : 3;
    else if (Math.abs(p.vx) > 0.35) frame = Math.floor(this.anim) % 4;
    const bob = this.flying ? Math.round(Math.sin(this.clock * 8) * 2) : 0;
    if (sheet) {
      const dw = CELL_W;
      const dh = CELL_H;
      ctx.save();
      ctx.translate(feetX, feetY + bob);
      if (p.facing < 0) ctx.scale(-1, 1);
      ctx.drawImage(sheet, frame * CELL_W, 0, CELL_W, CELL_H, -Math.floor(dw / 2), -dh + 2, dw, dh);
      ctx.restore();
      return;
    }
    ctx.save();
    ctx.translate(feetX, feetY + bob);
    if (p.facing < 0) ctx.scale(-1, 1);
    ctx.fillStyle = "#6b3a22";
    ctx.fillRect(-6, -28, 12, 8);
    ctx.fillStyle = "#f0c09a";
    ctx.fillRect(-5, -24, 10, 8);
    ctx.fillStyle = "#1c1a18";
    ctx.fillRect(1, -22, 2, 2);
    ctx.fillStyle = "#2f8f86";
    ctx.fillRect(-5, -16, 10, 9);
    ctx.fillStyle = "#6b4228";
    ctx.fillRect(-5, -7, 4, 4);
    ctx.fillRect(1, -7, 4, 4);
    ctx.fillStyle = "#5aaa45";
    ctx.fillRect(-1, -30, 2, 3);
    ctx.restore();
  }

  private async loadArt() {
    try {
      const [atlas, walk, jumpSheet] = await Promise.all([
        loadImage("/tiles/atlas.png"),
        loadImage("/sprites/walk.png"),
        loadImage("/sprites/jump.png"),
      ]);
      this.atlas = atlas;
      this.walk = walk;
      this.jumpSheet = jumpSheet;
    } catch {
      /* colored fallbacks stay on */
    }
  }

  private onKeyDown = (e: KeyboardEvent) => {
    const game = [
      "KeyA", "KeyD", "KeyW", "KeyS", "KeyF", "KeyE", "KeyQ",
      "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Space", "Escape",
    ];
    if (game.includes(e.code) || e.code.startsWith("Digit")) e.preventDefault();
    this.keys.add(e.code);
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onBlur = () => {
    this.keys.clear();
    this.touch = { left: false, right: false, up: false, down: false, jump: false };
    this.painting = null;
  };

  private onPointerDown = (e: PointerEvent) => {
    if (!this.ui.current.started || this.ui.current.paused) return;
    this.sfx.unlock();
    if (e.button === 1) {
      e.preventDefault();
      this.pickAt(e.clientX, e.clientY);
      return;
    }
    const mode: Tool =
      e.pointerType === "mouse" ? (e.button === 2 ? "break" : "place") : this.ui.current.tool;
    this.painting = mode;
    this.lastPaint = "";
    this.canvas.setPointerCapture(e.pointerId);
    this.paintPointer(e.clientX, e.clientY, mode);
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.ui.current.started || this.ui.current.paused) return;
    if (this.painting) this.paintPointer(e.clientX, e.clientY, this.painting);
    else if (e.pointerType === "mouse") {
      const rect = this.canvas.getBoundingClientRect();
      const ix = ((e.clientX - rect.left) / rect.width) * this.iw;
      const iy = ((e.clientY - rect.top) / rect.height) * this.ih;
      const originX = Math.round(this.camX * TILE);
      const originY = Math.round(this.camY * TILE);
      this.aim = {
        x: Math.floor((ix + originX) / TILE),
        y: Math.floor((iy + originY) / TILE),
      };
    }
  };

  private onPointerUp = () => {
    this.painting = null;
    this.lastPaint = "";
  };

  private onContext = (e: Event) => {
    e.preventDefault();
  };

  private onWheel = (e: WheelEvent) => {
    if (!this.ui.current.started) return;
    e.preventDefault();
    const slots = this.ui.current.slots;
    if (!slots.length) return;
    const cur = Math.max(0, slots.indexOf(this.ui.current.blockId));
    const next = (cur + (e.deltaY > 0 ? 1 : -1) + slots.length) % slots.length;
    const id = slots[next];
    if (id) this.onSlot?.(id);
  };

  private onResize = () => {
    this.resize();
  };

  private onHide = () => {
    if (document.visibilityState === "hidden") this.save();
    this.keys.clear();
  };

  private probeSetKeys = (codes: string[]) => {
    this.forced = new Set(codes);
  };

  private bind() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    window.addEventListener("resize", this.onResize);
    document.addEventListener("visibilitychange", this.onHide);
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    this.canvas.addEventListener("pointermove", this.onPointerMove);
    this.canvas.addEventListener("pointerup", this.onPointerUp);
    this.canvas.addEventListener("pointercancel", this.onPointerUp);
    this.canvas.addEventListener("contextmenu", this.onContext);
    this.canvas.addEventListener("wheel", this.onWheel, { passive: false });
    const obs = new ResizeObserver(this.onResize);
    obs.observe(this.canvas);
    this.resizeObserver = obs;
  }

  private resizeObserver: ResizeObserver | null = null;

  private unbind() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    window.removeEventListener("resize", this.onResize);
    document.removeEventListener("visibilitychange", this.onHide);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerup", this.onPointerUp);
    this.canvas.removeEventListener("pointercancel", this.onPointerUp);
    this.canvas.removeEventListener("contextmenu", this.onContext);
    this.canvas.removeEventListener("wheel", this.onWheel);
    this.resizeObserver?.disconnect();
  }

  private attachProbe() {
    window.__controlsTest = {
      getYaw: () => (this.player.facing > 0 ? 0 : Math.PI),
      getSpeed: () => this.player.vx,
      getX: () => this.player.x,
      getY: () => this.player.y,
      isFlying: () => this.flying,
      setKeys: this.probeSetKeys,
    };
    window.__blokyuva = {
      ready: true,
      getBlock: (x, y) => this.getFg(x, y),
      getBg: (x, y) => this.getBg(x, y),
      debugPlace: () => {
        const hit = this.editAhead("place");
        if (!hit) return null;
        return { ...hit, id: this.getFg(hit.x, hit.y) || this.getBg(hit.x, hit.y) };
      },
      debugBreak: () => this.editAhead("break"),
    };
  }
}
