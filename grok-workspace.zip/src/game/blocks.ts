export type Category = "doga" | "yapi" | "dekor" | "oda";

export interface BlockDef {
  id: number;
  name: string;
  category: Category;
  solid: boolean;
  background: boolean;
  climb: boolean;
  liquid: boolean;
  transparent: boolean;
  unbreakable: boolean;
  hotbar: boolean;
  color: string;
}

export const AIR = 0;

const def = (
  id: number,
  name: string,
  category: Category,
  color: string,
  flags: Partial<Omit<BlockDef, "id" | "name" | "category" | "color">> = {},
): BlockDef => ({
  id,
  name,
  category,
  color,
  solid: flags.solid ?? true,
  background: flags.background ?? false,
  climb: flags.climb ?? false,
  liquid: flags.liquid ?? false,
  transparent: flags.transparent ?? false,
  unbreakable: flags.unbreakable ?? false,
  hotbar: flags.hotbar ?? true,
});

export const ID = {
  air: 0,
  grass: 1,
  dirt: 2,
  stone: 3,
  cobble: 4,
  log: 5,
  planks: 6,
  leaves: 7,
  sand: 8,
  brick: 9,
  glass: 10,
  stonebrick: 11,
  woolRed: 12,
  woolBlue: 13,
  woolYellow: 14,
  woolWhite: 15,
  woolGreen: 16,
  door: 17,
  torch: 18,
  flower: 19,
  bed: 20,
  chest: 21,
  table: 22,
  ladder: 23,
  bookshelf: 24,
  furnace: 25,
  bgWood: 26,
  bgStone: 27,
  wallpaper: 28,
  bedrock: 29,
  hay: 30,
  woolPink: 31,
  water: 32,
} as const;

export const BLOCKS: (BlockDef | null)[] = [];
BLOCKS[ID.grass] = def(ID.grass, "Çimen", "doga", "#5ea842");
BLOCKS[ID.dirt] = def(ID.dirt, "Toprak", "doga", "#8d5a34");
BLOCKS[ID.stone] = def(ID.stone, "Taş", "doga", "#8a8a8e");
BLOCKS[ID.cobble] = def(ID.cobble, "Kırıktaş", "doga", "#6e6e72");
BLOCKS[ID.log] = def(ID.log, "Odun", "doga", "#6b4428");
BLOCKS[ID.planks] = def(ID.planks, "Tahta", "yapi", "#c49a5c");
BLOCKS[ID.leaves] = def(ID.leaves, "Yaprak", "doga", "#3e8c34", { transparent: true });
BLOCKS[ID.sand] = def(ID.sand, "Kum", "doga", "#e4d2a0");
BLOCKS[ID.brick] = def(ID.brick, "Tuğla", "yapi", "#b4543e");
BLOCKS[ID.glass] = def(ID.glass, "Cam", "yapi", "#c5e4f2", { transparent: true });
BLOCKS[ID.stonebrick] = def(ID.stonebrick, "Taş tuğla", "yapi", "#9a9aa0");
BLOCKS[ID.woolRed] = def(ID.woolRed, "Kırmızı yün", "yapi", "#c44850");
BLOCKS[ID.woolBlue] = def(ID.woolBlue, "Mavi yün", "yapi", "#3d78c4");
BLOCKS[ID.woolYellow] = def(ID.woolYellow, "Sarı yün", "yapi", "#e0b84a");
BLOCKS[ID.woolWhite] = def(ID.woolWhite, "Beyaz yün", "yapi", "#f2f0ea");
BLOCKS[ID.woolGreen] = def(ID.woolGreen, "Yeşil yün", "yapi", "#3c9a58");
BLOCKS[ID.door] = def(ID.door, "Kapı", "yapi", "#a87440", { solid: false, transparent: true });
BLOCKS[ID.torch] = def(ID.torch, "Meşale", "dekor", "#f0a030", { solid: false, transparent: true });
BLOCKS[ID.flower] = def(ID.flower, "Çiçek", "dekor", "#ef7090", { solid: false, transparent: true });
BLOCKS[ID.bed] = def(ID.bed, "Yatak", "dekor", "#c43c48", { solid: false, transparent: true });
BLOCKS[ID.chest] = def(ID.chest, "Sandık", "dekor", "#a86a32");
BLOCKS[ID.table] = def(ID.table, "Masa", "dekor", "#c48a48", { solid: false, transparent: true });
BLOCKS[ID.ladder] = def(ID.ladder, "Merdiven", "yapi", "#a87844", {
  solid: false,
  climb: true,
  transparent: true,
});
BLOCKS[ID.bookshelf] = def(ID.bookshelf, "Kitaplık", "dekor", "#8a5a32");
BLOCKS[ID.furnace] = def(ID.furnace, "Ocak", "dekor", "#6a6a6e");
BLOCKS[ID.bgWood] = def(ID.bgWood, "Arka tahta", "oda", "#6e5434", {
  solid: false,
  background: true,
});
BLOCKS[ID.bgStone] = def(ID.bgStone, "Arka taş", "oda", "#5c5c64", {
  solid: false,
  background: true,
});
BLOCKS[ID.wallpaper] = def(ID.wallpaper, "Duvar kağıdı", "oda", "#f0e2c4", {
  solid: false,
  background: true,
});
BLOCKS[ID.bedrock] = def(ID.bedrock, "Ana kaya", "doga", "#1c1c20", {
  hotbar: false,
  unbreakable: true,
});
BLOCKS[ID.hay] = def(ID.hay, "Saman", "doga", "#e0b848");
BLOCKS[ID.woolPink] = def(ID.woolPink, "Pembe yün", "yapi", "#e088b0");
BLOCKS[ID.water] = def(ID.water, "Su", "doga", "#3a8ec8", {
  solid: false,
  liquid: true,
  transparent: true,
});

export const CATEGORIES: { id: Category; label: string }[] = [
  { id: "doga", label: "Doğa" },
  { id: "yapi", label: "Yapı" },
  { id: "dekor", label: "Eşya" },
  { id: "oda", label: "Oda" },
];

export function hotbar(category: Category): BlockDef[] {
  const list: BlockDef[] = [];
  for (const block of BLOCKS) {
    if (block && block.hotbar && block.category === category) list.push(block);
  }
  return list;
}

export function blockAt(id: number): BlockDef | null {
  return BLOCKS[id] ?? null;
}

export const ATLAS_COLS = 8;

export function atlasCell(id: number): { col: number; row: number } | null {
  if (id <= 0) return null;
  const a = id - 1;
  return { col: a % ATLAS_COLS, row: Math.floor(a / ATLAS_COLS) };
}
