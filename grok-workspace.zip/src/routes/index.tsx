import { createFileRoute } from "@tanstack/react-router";
import { Blokyuva } from "@/components/Blokyuva";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Blokyuva />;
}
